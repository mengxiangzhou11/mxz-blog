var $, table, layer, form;
var param = {};
var status = "";
var currentPage;
var jsonData;
var arr = [];
var sum = 0;
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	form = layui.form;


	// 获取数据
	param = {};
	showTable("reorder/selectReorderLay", param, true)


	//监听行工具事件
	watchToolBar();


	//导出Excel
	$("#exportExcel").click(function() {
		console.log("aa")
		getData("reorder/selectReorderLay", {
			"page": 1,
			"limit": 10000
		}, res => {
			for (var i = 0; i < res.data.length; i++) {
				var json = new Object();
				json.reorderNo = res.data[i].reorderNo;
				json.orderType = res.data[i].order.orderType==3?"拍拍贷租赁":"支付宝租赁";
				json.reorderExpcom = res.data[i].reorderExpcom;
				json.orderOutOrderNo = res.data[i].order.orderOutOrderNo;
				json.attrDeposit = res.data[i].order.attrDeposit / 100;
				if (res.data[i].status == 1) {
					json.status = "运送中"
				} else if (res.data[i].status == 2) {
					json.status = "未解冻"
				} else if (res.data[i].status == 3) {
					json.status = "已解冻"
				}
				json.reorderCreateTime = stampToTime(res.data[i].reorderCreateTime);
				json.goodsTitle = res.data[i].order.goodsTitle;
				json.orderPrice = res.data[i].order.orderPrice / 100;
				json.attrTitle = res.data[i].order.attrTitle;
				json.orderPaytime = stampToTime(res.data[i].order.orderPaytime);
				json.leaseTerm = res.data[i].order.leaseTerm;
				json.orderFinalpay = res.data[i].order.orderFinalpay / 100;
				json.orderLeave = res.data[i].order.orderLeave;
				arr.push(json)
				sum += res.data[i].order.orderFinalpay / 100;
			}
			jsonData = arr;
			let str = `快递单号,订单类型,快递公司,订单号,押金(元),状态,创建时间,商品名称,订单总价,商品属性,付款时间,租赁期限,最终付款(元),留言\n`;
			//增加\t为了不让表格显示科学计数法或者其他格式
			for (let i = 0; i < jsonData.length; i++) {
				for (let item in jsonData[i]) {
					str += `${jsonData[i][item] + '\t'},`;
				}
				str += '\n';
			}
			str += `合计,,,,,,,,,,,,${sum.toFixed(2)}元`;
			//encodeURIComponent解决中文乱码
			let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
			//通过创建a标签实现
			let link = document.createElement("a");
			link.href = uri;
			//对下载的文件命名
			link.download = "订单记录.xlsx";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		})
	})

});

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 确认收货
		if (obj.event === 'toCenter') {
			if (!showMsg(resData, 2, "您已确认收货") || !showMsg(resData, 3, "您已确认收货")) {
				return;
			}
			layer.confirm("确认收货？", {
				icon: 3,
				title: '提示',
				offset: '50%',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					param.reorderId = resData.reorderId
					param.reorderNo = resData.reorderNo
					param.reorderExpcom = resData.reorderExpcom
					param.status = 2
					param.reorderPhoto = resData.reorderPhoto
					param.userId = resData.userId
					getData("reorder/updateReorderStatus", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('确认收货成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 重新渲染表格
								renderCurrentPage();
							});
						} else {
							layer.msg(res.msg, {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
		// 扣除赔偿金
		if (obj.event === 'deduct') {
			if (!showMsg(resData, 1, "请先确认收货") || !showMsg(resData, 3, "您已解冻该订单")) {
				return;
			}
			x_admin_show("扣除赔偿金", "../deduct/deduct.html?orderId=" + resData.orderId)
		}
		// 解冻押金
		if (obj.event === 'unfreeze') {
			if (!showMsg(resData, 1, "请先确认收货") || !showMsg(resData, 3, "您已解冻该订单")) {
				return;
			}
			layer.confirm("确定解冻此押金？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					// param.orderId = 84
					getData("pay/unfreeze", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('解冻成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 重新渲染表格
								renderCurrentPage();
							});
						} else {
							layer.msg(res.msg || "解冻失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}

	});


	// 监听select
	form.on('select(chooseStatic)', function(data) {
		status = data.value;
		currentPage = 1;
		$("#searchInput").val("")
		renderCurrentPage();
	});

	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.orderNo = content;
		showTable("reorder/selectReorderByNo", param, false)
	});

	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.tel = content;
		showTable("reorder/selectReorderByTel", param, false)
	});

}

/**
 * 重新渲染当前页的表格
 */
function renderCurrentPage() {
	var page = {
		curr: currentPage
	}
	if (status == -1 || status == "") showTable("reorder/selectReorderLay", {}, page)
	else {
		param = {}
		param.status = status
		showTable("reorder/selectReorderLay", param, page)
	}
}

/**
 * 提示信息
 */
function showMsg(resData, num, tips) {
	if (resData.status == num) {
		layer.msg(tips, {
			time: 1500
		});
		return false;
	} else {
		return true
	}
}

/**
 * 渲染表格
 */
function showTable(url, param, page) {
	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		page: page,
		where: param,
		headers: {
			token: getSession("token")
		},
		size: 'lg',
		// toolbar: '#Exportbar',
		// defaultToolbar: [],
		done: function(res, curr, count) {
			currentPage = curr
		},
		parseData: function(res) { //res 即为原始返回的数据
			let resData = res.data; //结果
			let newData = []; //显示的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			// 非数组
			if (resData instanceof Array == false) {
				let temp = [];
				resData ? temp[0] = resData : "";
				resData = temp;
			}
			// 拼接对象
			for (var i in resData) {
				let temp = Object.assign(resData[i], resData[i].order)
				newData.push(temp)
			}
			return {
				"code": res.code, //解析接口状态
				"data": newData, //解析数据列表
				"count": res.count
			};

		},
		cols: [
			[
				//表头
				{
					field: 'reorderNo',
					title: '快递单号',
					align: "center",
					width: 250,
				},
				{
					field: 'orderType',
					title: '订单类型',
					width: 150,
					sort: true,
					align: "center",
					templet: "#orderType"
				},
				{
					field: 'reorderExpcom',
					title: '快递公司',
					width: 200,
					align: "center",
				}, {
					field: 'reorderPhoto',
					title: '证据',
					width: 150,
					align: "center",
					templet: '#reorderPhoto'
				}, {
					title: '状态',
					align: "center",
					style: "margin-right: 250px !important;",
					width: 100,
					templet: '#orderStatus',
				},
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					align: "center"
				}, {
					field: 'attrDeposit',
					title: '剩余商品押金(元)',
					width: 180,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'reorderCreateTime',
					title: '归还创建时间',
					width: 180,
					align: "center",
					templet: "#reorderCreateTime"
				}, {
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center"
				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 200,
					align: "center",
					templet: "#orderPrice"
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					width: 200,
					align: "center",
				}, {
					field: 'orderPaytime',
					title: '付款时间',
					width: 200,
					align: "center",
				}, {
					field: 'orderLeave',
					title: '留言',
					align: "center",
					width: 300,
				}, {
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					width: 150,
				}, {
					field: 'orderFinalpay',
					title: '最终付款/元(不含押金)',
					align: "center",
					width: 270,
					templet: "#orderFinalpay"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 350,
					align: "center"
				}
			]
		]

	});
}
