var url = parent.url;
var form, $, upload;
var phoneData;
var wechatData;
var addressData;
var reRentDay;
var extraStatus;
var rentTipData;
layui.use(['upload', 'form'], function() {
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;

	// 获取数据
	getAllValue()

	toSubmit("rentTipForm")

	toSubmit("addressForm")

	toSubmit("phoneForm")

	toSubmit("wechatForm")

	toSubmit("rentForm")

	toswitch()
});

function toswitch() {
	//监听指定开关
	form.on('switch(switchTest)', function(data) {
		if (this.checked) {
			extraStatus.status = 0;
		} else {
			extraStatus.status = 1;
		}
		postJsonData("extra/updateExtra", extraStatus, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});
}
/**
 * 获取数据
 * 渲染表单
 */
function getAllValue() {
	getData('extra/selectAllExtra', {}, res => {
		console.log(res)
		let value = res.data;
		phoneData = value.extra1.extraTitle;
		wechatData = value.extra2.extraTitle;
		addresstData = value.extra3.extraTitle;
		form.val('phoneForm', {
			"value": phoneData,
		})
		form.val('wechatForm', {
			"value": wechatData,
		})
		form.val('addressForm', {
			"value": addresstData,
		})
	})

	getData('extra/selectMin_DAY', {}, res => {
		reRentDay = res.data;
		form.val('rentForm', {
			"value": reRentDay.extraTitle,
		})
	})
	getData('extra/selectAgentSwitch', {}, res => {
		extraStatus = res.data;
		if (res.data.status == 0) {
			$("#checkbox").prop('checked', true)
			form.render();
		}
	})

	getData('extra/getZLXY', {}, res => {
		rentTipData = res.data;
		form.val('rentTipForm', {
			"value": rentTipData.extraTitle,
		})
	})
}


/*提交表单*/
function toSubmit(btnFilter) {
	//监听提交
	form.on(`submit(${btnFilter})`, function(data) {
		console.log(data)
		var value = data.field.value;
		let param;
		if (btnFilter == 'phoneForm') {
			param = {
				extraId: 1,
				extraTitle: value
			}
		} else if (btnFilter == 'wechatForm') {
			param = {
				extraId: 2,
				extraTitle: value
			}
		} else if (btnFilter == 'addressForm') {
			param = {
				extraId: 3,
				extraTitle: value
			}
		} else if (btnFilter == 'rentForm') {
			param = {
				extraId: 4,
				extraTitle: value
			}
		} else if (btnFilter == 'rentTipForm') {
			param = {
				extraId: rentTipData.extraId,
				extraTitle: value
			}
		}

		postJsonData("extra/updateExtra", param, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});
}
