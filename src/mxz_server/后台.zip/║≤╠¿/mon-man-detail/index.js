var $;
var form;
var resData = JSON.parse(getSession("curOrder"));
clearSession("curOrder")
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;
	form = layui.form;

	form.val("titleForm", {
		"orderOutOrderNo": resData.orderOutOrderNo,
		"orderExpress": resData.orderExpress || "暂无",
		"userName": resData.userName || "暂无",
		"userTel": resData.userTel || "暂无",
		"orderAddr": resData.orderAddr || "暂无",
		"orderCreatime": resData.orderCreatime,
		"goodsTitle": resData.goodsTitle,
		"orderPrice": resData.orderPrice / 100,
		"orderPrice1": (resData.orderPrice - resData.orderOffset) / 100,
		"orderOffset": resData.orderOffset / 100,
		"attrDeposit": function() {
			if (resData.orderType == 2) {
				return resData.attrDeposit / 100 + "元(信用免押)"
			} else {
				return resData.attrDeposit / 100 + "元(资金冻结)"
			}
		},
		"attrTitle": resData.attrTitle,
		"leaseLimitDate": resData.leaseLimitDate,
		// "leaseTerm": resData.leaseTerm - 1 + "期",
		// "leaseTerm1": resData.leaseLimitDate - resData.leaseTerm - 1 + "期",
		"attrPrice": resData.attrPrice / 100,
		"orderLeave": resData.orderLeave || "暂无",
		"orderMark": resData.orderMark || "暂无",
		"orderFinalpay": resData.orderFinalpay / 100,
		"orderFinalpay1": (resData.orderPrice - resData.orderOffset - resData.orderFinalpay) / 100,
		"orderStatus": function() {
			if (resData.orderStatus == 0) {
				return '已取消'
			} else if (resData.orderStatus == 1) {
				return '未付款'
			} else if (resData.orderStatus == 2) {
				return '已发货'
			} else if (resData.orderStatus == 3) {
				return '租赁中'
			} else if (resData.orderStatus == 4) {
				return '逾期中'
			} else if (resData.orderStatus == 5) {
				return '归还中'
			} else if (resData.orderStatus == 6) {
				return '已归还'
			} else if (resData.orderStatus == 7) {
				return '待发货'
			} else if (resData.orderStatus == 8) {
				return '逾期且已扣除押金'
			} else if (resData.orderStatus == 9) {
				return '订单已经完结'
			}
		},
	})

});
