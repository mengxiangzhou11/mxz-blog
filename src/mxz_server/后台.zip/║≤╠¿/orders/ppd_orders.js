var $, table, layer, form, tableIns;
var admin = getSession("admin");
if (admin != null) {
	admin = JSON.parse(admin);
}
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	table = layui.table;
	form = layui.form;
	$ = layui.jquery;
	layer = layui.layer;
	// 获取数据，渲染表格
	param = {};
	showTable("payOrder/getList", param, true)

	watchSelect()

	//导出Excel
	$("#exportExcel").click(function() {
		console.log("aa")
		getData("payOrder/getList", {
			"page": -1,
			"limit": -1
		}, res => {
			for (var i = 0; i < res.data.length; i++) {
				var json = new Object();
				json.orderOutOrderNo = res.data[i].orderOutOrderNo;
				json.orderExpress = res.data[i].orderExpress;
				json.userName = res.data[i].userName;
				json.userTel = res.data[i].userTel;
				json.orderAddr = res.data[i].orderAddr;
				json.orderCreatime = stampToTime(res.data[i].orderCreatime);
				json.goodsTitle = res.data[i].goodsTitle;
				json.orderPrice = res.data[i].orderPrice / 100;
				json.attrDeposit = res.data[i].attrDeposit;
				json.attrTitle = res.data[i].attrTitle;
				json.leaseLimitDate = res.data[i].leaseLimitDate;
				json.leaseTerm = res.data[i].leaseTerm;
				json.orderFinalpay = res.data[i].orderFinalpay / 100;
				json.orderLeave = res.data[i].orderLeave;
				json.orderType = res.data[i].orderType == 3 ? "租赁中" : "其它";
				arr.push(json)
				sum += res.data[i].orderFinalpay / 100;
			}
			jsonData = arr;
			let str = `订单号,快递单号,用户名,联系电话,收货地址,创建时间,商品名称,订单总价,押金(元),商品属性,租赁期限,已缴期数,最终付款(元),留言,状态\n`;
			//增加\t为了不让表格显示科学计数法或者其他格式
			for (let i = 0; i < jsonData.length; i++) {
				for (let item in jsonData[i]) {
					str += `${jsonData[i][item] + '\t'},`;
				}
				str += '\n';
			}
			str += `合计,,,,,,,,,,,,${sum.toFixed(2)}元`;
			//encodeURIComponent解决中文乱码
			let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
			//通过创建a标签实现
			let link = document.createElement("a");
			link.href = uri;
			//对下载的文件命名
			link.download = "订单记录.xlsx";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		})
	})
});

/**
 * 渲染表格
 */
function showTable(url, param, page) {
	//插入表格数据
	tableIns = table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		size: 'lg',
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		done: function(res, curr, count) {},
		cols: [
			[ //表头
				{
					field: 'orderNo',
					title: '订单编号',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'payOrderNo',
					title: '分期订单号',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'payOrderVal',
					title: '本次支付金额/元',
					width: 200,
					sort: true,
					align: "center",
					style: "color:red",
					templet: "#payOrderVal"
				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					sort: true,
					width: 150,
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					width: 200,
					sort: true,
					templet: "#orderCreatime",
					align: "center",
				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'attrPrice',
					title: '该商品属性每天的租金(元)',
					width: 250,
					sort: true,
					align: "center",
					templet: "#attrPrice"
				},
				{
					field: 'orderStatus',
					title: '状态',
					width: 120,
					sort: true,
					align: "center",
					fixed: "right",
					templet: "#orderStatus"
				}
			]
		],

	});

}



/**
 * 监听行工具事件
 */
function watchSelect() {
	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render();
		var orderNo = data.field.content;
		tableIns.reload({
			where: {
				orderNo,
				status: -1
			}
		})
	});


	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render();
		var userTel = data.field.content;
		tableIns.reload({
			where: {
				userTel,
				status: -1
			}
		})
	});


	// 监听select
	form.on('select(chooseStatic)', function(data) {
		$("#searchInput").val('');
		let status = data.value;
		tableIns.reload({
			where: {
				status
			}
		})
	});
}
