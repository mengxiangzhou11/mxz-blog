var $, table, layer, form;
var param = {};
var sortType = "";
var currentPage;

var jsonData;
var arr=[];
var sum=0;
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	table = layui.table;
	form = layui.form;
	$ = layui.jquery;
	layer = layui.layer;

	// 获取数据，渲染表格
	param = {};
	showTable("badrec/getList", param, false)


	//监听行工具事件
	watchToolBar();

	// 监听输入单号
	watchEdit();

	//导出Excel
	$("#exportExcel").click(function(){
		console.log("aa")
		getData("badrec/getList",{"page":1,"limit":10000},res => {
			for (var i=0;i<res.data.length;i++){
				var json = new Object();
				json.orderOutOrderNo=res.data[i].order.orderOutOrderNo;
				json.amount=res.data[i].order.amount/100;
				json.orderExpress=res.data[i].order.orderExpress;
				json.userName=res.data[i].order.userName;
				json.userTel=res.data[i].order.userTel;
				json.orderAddr=res.data[i].order.orderAddr;
				json.orderCreatime=stampToTime(res.data[i].order.orderCreatime);
				json.goodsTitle=res.data[i].order.goodsTitle;
				json.orderPrice=res.data[i].order.orderPrice/100;
				json.attrDeposit=res.data[i].order.attrDeposit/100;
				json.attrTitle=res.data[i].order.attrTitle;
				json.leaseLimitDate=res.data[i].order.leaseLimitDate;
				json.leaseTerm=res.data[i].order.leaseTerm;
				json.orderFinalpay=res.data[i].order.orderFinalpay/100;
				json.orderLeave=res.data[i].order.orderLeave;
				arr.push(json)
				sum+=res.data[i].orderFinalpay/100;
			}
			jsonData = arr;
			 let str = `订单号,代扣金额(元),快递单号,用户名,联系电话,收货地址,创建时间,商品名称,订单总价,押金(元),商品属性,租赁期限,已缴期数,最终付款(元),留言\n`;
			  //增加\t为了不让表格显示科学计数法或者其他格式
			  for(let i = 0 ; i < jsonData.length; i++ ){
			    for(let item in jsonData[i]){
			        str+=`${jsonData[i][item] + '\t'},`;     
			    }
			    str+='\n';
			  }
			  str+=`合计,,,,,,,,,,,,,${sum.toFixed(2)}元`;
			  //encodeURIComponent解决中文乱码
			  let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
			  //通过创建a标签实现
			  let link = document.createElement("a");
			  link.href = uri;
			  //对下载的文件命名
			  link.download =  "订单记录.xlsx";
			  document.body.appendChild(link);
			  link.click();
			  document.body.removeChild(link);
			})
		})
			
	
});


/**
 * 监听行内编辑
 */
function watchEdit() {
	table.on('edit(list)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		console.log('编辑-->', obj)
		//obj.update(fields) //修改当前行数据
		let field = obj.field;
		let param = obj.data.order;
		// 快递单号
		if (field == "orderExpress") {
			param[field] = obj.value;
			if (param.orderStatus == 7) {
				if (!obj.value) {
					param.orderStatus = 7;
				} else {
					param.orderStatus = 2;
				}
			}
			// 更新订单
			updateOrder(param, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}
		// 备注
		else if (field == "orderMark") {
			// 更新订单
			param[field] = obj.value;
			updateOrder(param, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}
		// 修改买断金额
		else if (field == "buyoutAmount") {
			// 更新订单
			param[field] = parseInt(obj.value) * 100;
			updateOrder(param, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}

	});
}

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 代扣
		if (obj.event = "withhold") {
			layer.confirm("确定代扣此订单？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.recId = resData.badrecId
					getData("badrec/dealRec", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('代扣成功', {
								icon: 1,
								time: 1500
							}, function() {
								table.reload('list')
							});
						} else {
							layer.msg(res.msg || "代扣失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
	});

	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		table.reload('list', {
			where: {
				orderNo: content
			}
		})
	});
}

/**
 * 更新订单状态
 */
function updateOrder(resData, Callback) {
	postJsonData("order/updateOrder", resData, res => {
		Callback(res);
	})
}


/**
 * 渲染表格
 */
function showTable(url) {

	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: false,
		size: 'lg',
		// toolbar: '#Exportbar',
		// defaultToolbar: [],
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		// parseData: function(res) { //res 即为原始返回的数据
		// 	console.log(res);
		// 	for (let i = 0; i < res.data.size; i++) {
		// 		if (res.data[i].buyoutAmount > 0) {
		// 			res.data[i].buyoutAmount = res.data[i].buyoutAmount / 100
		// 		}
		// 	}
		// 	return {
		// 		"code": res.code, //解析接口状态
		// 		"msg": res.msg, //解析提示文本
		// 		"count": res.count, //解析数据长度
		// 		"data": res.data //解析数据列表
		// 	};
		// },
		cols: [
			[ //表头
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					sort: true,
					align: "center",
					templet: (d) => {
						return d.order.orderOutOrderNo
					}
				},
				{
					field: 'amount',
					title: '代扣金额/元',
					width: 120,
					sort: true,
					align: "center",
					style:'color:red',
					templet:"#amount"
				},
				{
					field: 'orderExpress',
					title: '快递单号(点击单元格可编辑)',
					width: 240,
					style: "color:red",
					align: "center",
					sort: true,
					edit: 'text',
					templet: (d) => {
						return d.order.orderExpress||""
					}
				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
					templet: (d) => {
						return d.order.userName
					}
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					sort: true,
					width: 150,
					templet: (d) => {
						return d.order.userTel
					}
				}, {
					field: 'orderAddr',
					title: '订单收货地址',
					width: 250,
					align: "center",
					templet: (d) => {
						return d.order.orderAddr
					}
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					width: 200,
					sort: true,
					align: "center",
					templet: (d) => {
						return d.order.orderCreatime
					}
				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
					templet: (d) => {
						return d.order.goodsTitle
					}
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 200,
					sort: true,
					align: "center",
					templet: "#orderPrice"
				},
				{
					field: 'attrDeposit',
					title: '商品押金',
					width: 200,
					sort: true,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center",
					templet: (d) => {
						return d.order.attrTitle
					}
				},
				
				{
					field: 'leaseLimitDate',
					title: '租赁期限 (月)',
					width: 150,
					sort: true,
					align: "center",
					templet: "#leaseLimitDate"
				},
				{
					field: 'attrPrice',
					title: '该商品属性每天的租金(元)',
					width: 250,
					sort: true,
					align: "center",
					templet: "#attrPrice"
				},
				{
					field: 'orderLeave',
					title: '留言',
					align: "center",
					width: 300,
					templet: (d) => {
						return d.order.orderLeave
					}
				}, {
					field: 'orderMark',
					title: '客服备注(点击单元格可编辑)',
					width: 240,
					style: "color:blue",
					align: "center",
					edit: 'text',
					templet: (d) => {
						return d.order.orderMark||""
					}
				}, {
					field: 'orderFinalpay',
					title: '最终付款(元)',
					align: "center",
					width: 270,
					sort: true,
					templet: "#orderFinalpay"
				},
				{
					field: 'buyoutAmount',
					title: '买断金额(元)',
					width: 270,
					style: "color:red",
					align: "center",
					sort: true,
					edit: 'text',
					templet: "#buyoutAmount"
				},
				{
					title: '状态/操作',
					align: "center",
					width: 150,
					fixed: "right",
					toolbar: '#orderStatus',
				},
			]
		],

	});

}
