var $, table, layer, form;
var param = {};
var sortType = "";
var currentPage;
var jsonData;
var arr=[];
var sum=0;

layui.use(['layer', 'jquery', 'form', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	form = layui.form;


	// 获取数据，渲染表格
	param = {};
	showTable("order/selectOrders1", param, true)


	//监听行工具事件
	watchToolBar();

	// 监听输入单号
	// watchEdit();


//导出Excel
	$("#exportExcel").click(function(){
		console.log("aa")
		getData("order/selectOrders1",{"page":1,"limit":10000},res => {
			for (var i=0;i<res.data.length;i++){
				var json = new Object();
				json.orderOutOrderNo=res.data[i].orderOutOrderNo;
				json.orderExpress=res.data[i].orderExpress;
				json.userName=res.data[i].userName;
				json.userTel=res.data[i].userTel;
				json.orderAddr=res.data[i].orderAddr;
				json.orderCreatime=stampToTime(res.data[i].orderCreatime);
				json.goodsTitle=res.data[i].goodsTitle;
				json.orderPrice=res.data[i].orderPrice/100;
				json.attrDeposit=res.data[i].userTel;
				json.attrTitle=res.data[i].attrTitle;
				json.leaseLimitDate=res.data[i].leaseLimitDate;
				json.leaseTerm=res.data[i].leaseTerm;
				json.orderFinalpay=res.data[i].orderFinalpay/100;
				json.orderLeave=res.data[i].orderLeave;
				if (res.data[i].finshStatus == 0) {
					json.finshStatus="正常";
				} else if (res.data[i].finshStatus == 1) {
					json.finshStatus="买断中";
				} else if(res.data[i].finshStatus == 2){
					json.finshStatus="已买断";
				}
				json.buyoutAmount=res.data[i].buyoutAmount/100;
				arr.push(json)
				sum+=res.data[i].orderFinalpay/100;
			}
			jsonData = arr;
			 let str = `订单号,快递单号,用户名,联系电话,收货地址,创建时间,商品名称,订单总价,押金(元),商品属性,租赁期限,已缴期数,最终付款(元),留言,状态,买断金额\n`;
			  //增加\t为了不让表格显示科学计数法或者其他格式
			  for(let i = 0 ; i < jsonData.length; i++ ){
			    for(let item in jsonData[i]){
			        str+=`${jsonData[i][item] + '\t'},`;     
			    }
			    str+='\n';
			  }
			  str+=`合计,,,,,,,,,,,,${sum.toFixed(2)}元`;
			  //encodeURIComponent解决中文乱码
			  let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
			  //通过创建a标签实现
			  let link = document.createElement("a");
			  link.href = uri;
			  //对下载的文件命名
			  link.download =  "订单记录.xlsx";
			  document.body.appendChild(link);
			  link.click();
			  document.body.removeChild(link);
			})
		})
			

});

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 扣除赔偿金
		if (obj.event == 'disagree') {
			// layer.confirm(`确定要退还买断金额(${resData.buyoutAmount/100}元)？`, {
				layer.confirm(`确定要退还买断金额)?`, {
				icon: 3,
				title: '提示',
				offset: '50%',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					param.finshStatus=1 //finshStatus==1表示退还买断金额
					// 扣除押金
					getData("order/setBuyOutStatus", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('退款成功', {
								icon: 1,
								time: 1500,
								}, function() {
									// 重新渲染表格
									renderCurrentPage();
							});

						} else {
							layer.msg(res.msg, {
								icon: 2,
								time: 1500,
								}, function() {
									// 重新渲染表格
									renderCurrentPage();
							});
						}
					})
				}
			});
		}
		// 解冻押金
		else if (obj.event == 'buyOut') {
			layer.confirm(`确定要同意买断吗?`, {
					icon: 3,
					title: '提示',
					offset: '50%',
					fixed: false,
					scrollbar: false,
					yes: function(index, layero) {
						var load;
						load = layer.load();
						param = {};
						param.orderId = resData.orderId
						param.finshStatus=2 //finshStatus==2表示同意买断
						getData("order/setBuyOutStatus", param, res => {
							layer.close(load);
							if (res.code == 0) {
								layer.msg('商品买断成功', {
									icon: 1,
									time: 1500,
									}, function() {
										// 重新渲染表格
										renderCurrentPage();
								});
							} else {
								layer.msg(res.msg, {
									icon: 2,
									time: 1500,
									}, function() {
										// 重新渲染表格
										renderCurrentPage();
								});
							}
						})
					}
				});
		}else{
				console.log(resData.orderOutOrderNo)
				setSession("orderOutOrderNo", JSON.stringify(resData.orderOutOrderNo))
				x_admin_show_all('买断支付记录', './tranRecord.html');
			}
	});

	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.orderNo = content;
		showTable("order/selectOrderByOrderNo", param, false)
	});


	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.tel = content;
		showTable("order/selectOrderByTel", param, false)
	});

}

/**
 * 更新订单状态
 */
function updateOrder(resData, Callback) {
	postJsonData("order/updateOrder", resData, res => {
		Callback(res);
	})
}


/**
 * 重新渲染当前页的表格
 */
function renderCurrentPage() {
	var page = {
		curr: currentPage
	}
	// 全部订单
	if (sortType == -1 || sortType == "") showTable("order/selectOrders", {}, page)
	// 分类订单
	else {
		param = {}
		param.sortType = sortType
		showTable("order/selectOrderSortLayui", param, page)
	}
}
/**
 * 渲染表格
 */
function showTable(url, param, page) {

	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		size: 'lg',
		// toolbar: '#Exportbar',
		// defaultToolbar: [],
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		cols: [
			[ //表头
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					sort:true,
					align: "center"
				},
				{
					field: 'orderExpress',
					title: '快递单号',
					width: 240,
					style: "color:red",
					align: "center",
					sort:true,
				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					sort:true,
					width: 150,
				}, {
					field: 'orderAddr',
					title: '订单收货地址',
					width: 250,
					align: "center",
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					width: 200,
					sort:true,
					align: "center",
				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 200,
					sort:true,
					align: "center",
					templet: "#orderPrice"
				},
				{
					field: 'attrDeposit',
					title: '商品押金',
					width: 200,
					sort:true,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center"
				},
				{
					field: 'leaseLimitDate',
					title: '租赁期限 (月)',
					width: 150,
					sort:true,
					align: "center",
					templet: "#leaseLimitDate"
				},
				{
					field: 'attrPrice',
					title: '该商品属性每天的租金(元)',
					width: 250,
					sort:true,
					align: "center",
					templet: "#attrPrice"
				},
				{
					field: 'orderLeave',
					title: '留言',
					align: "center",
					width: 300,
				}, {
					field: 'orderMark',
					title: '客服备注(点击单元格可编辑)',
					width: 240,
					style: "color:blue",
					align: "center",
					edit: 'text'
				}, {
					field: 'orderFinalpay',
					title: '最终付款(元)',
					align: "center",
					width: 270,
					sort:true,
					templet: "#orderFinalpay"
				},
				
				 {
					field: 'finshStatus',
					title: '买断状态 ',
					align: "center",
					width: 270,
					sort:true,
					templet: "#fStatus"
				},
				{
					field: 'buyoutAmount',
					title: '买断金额(元)',
					width: 270,
					style: "color:red",
					align: "center",
					sort:true,
					// edit: 'text',
					templet: "#buyoutAmount"
				},
				{
					title: '状态/操作',
					align: "center",
					width: 300,
					fixed: "right",
					toolbar: '#finshStatus',
				},
			]
		],

	});

}
