var $, table, layer, form;
var param = {};
var sortType = "";
var currentPage;
var days = 0; // 查询发送快递后自动收货天数
var admin = getSession("admin");
if (admin != null) {
	admin = JSON.parse(admin);
}
var jsonData;
var arr = [];
var sum = 0;
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	table = layui.table;
	form = layui.form;
	$ = layui.jquery;
	layer = layui.layer;

	// 查询发送快递后自动收货天数
	getData("extra/selectExtra3", {}, res => {
		if (res.code == 0) {
			days = res.data.extraTitle;
		}
	})

	// 获取数据，渲染表格
	param = {};
	showTable("order/selectOrders", param, true)


	//监听行工具事件
	watchToolBar();

	// 监听输入单号
	watchEdit();

	//导出Excel
	$("#exportExcel").click(function() {
		console.log("aa")
		getData("order/selectOrders", {
			"page": 1,
			"limit": 10000
		}, res => {
			for (var i = 0; i < res.data.length; i++) {
				var json = new Object();
				json.orderOutOrderNo = res.data[i].orderOutOrderNo;
				json.orderType = res.data[i].orderType == 3 ? "拍拍贷租赁" : "支付宝租赁";
				json.orderExpress = res.data[i].orderExpress;
				json.userName = res.data[i].userName;
				json.userTel = res.data[i].userTel;
				json.orderAddr = res.data[i].orderAddr;
				json.orderCreatime = stampToTime(res.data[i].orderCreatime);
				json.goodsTitle = res.data[i].goodsTitle;
				json.orderPrice = res.data[i].orderPrice / 100;
				json.attrDeposit = res.data[i].attrDeposit;
				json.attrTitle = res.data[i].attrTitle;
				json.leaseLimitDate = res.data[i].leaseLimitDate;
				json.leaseTerm = res.data[i].leaseTerm;
				json.orderFinalpay = res.data[i].orderFinalpay / 100;
				json.orderLeave = res.data[i].orderLeave;
				arr.push(json)
				sum += res.data[i].orderFinalpay / 100;
			}
			jsonData = arr;
			let str = `订单号,订单类型,快递单号,用户名,联系电话,收货地址,创建时间,商品名称,订单总价,押金(元),商品属性,租赁期限,已缴期数,最终付款(元),留言`;
			//增加\t为了不让表格显示科学计数法或者其他格式
			for (let i = 0; i < jsonData.length; i++) {
				for (let item in jsonData[i]) {
					str += `${jsonData[i][item] + '\t'},`;
				}
				str += '\n';
			}
			str += `合计,,,,,,,,,,,,${sum.toFixed(2)}元`;
			//encodeURIComponent解决中文乱码
			let uri = 'data:text/csv;charset=utf-8,\ufeff' + encodeURIComponent(str);
			//通过创建a标签实现
			let link = document.createElement("a");
			link.href = uri;
			//对下载的文件命名
			link.download = "订单记录.xlsx";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
		})
	})


});


/**
 * 监听行内编辑
 */
function watchEdit() {
	table.on('edit(list)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		let field = obj.field;
		let param = obj.data;
		let param1 = {}
		param1.orderId = param.orderId;
		// 快递单号
		if (field == "orderExpress") {
			param1[field] = obj.value;
			if (param.orderStatus == 7) {
				if (!obj.value) {
					param1.orderStatus = 7;
				} else {
					var oneTimeStamp = 24 * 60 * 60 * 1000; //一天的时间戳
					var nowTimeStamp = Date.parse(new Date()); //当前时间戳
					var startDate = nowTimeStamp + days * oneTimeStamp; //开始租赁时间
					var endDate = startDate + param.leaseLimitDate * oneTimeStamp; //结束租赁时间	
					param1.orderStatus = 2; //更新订单状态
					// param1.goodsLeaseStart=startDate;//更新租赁时间
					// param1.goodsLeaseEnd=endDate;//更新租赁时间
					// param1.lastPay=startDate;//同步上次扣款时间为起租日期
				}
			}
			// 更新订单
			updateOrder(param1, res => {
				// 操作成功添加操作记录
				var ope = {};
				ope.userId = admin.userId;
				ope.userNick = admin.userName;
				ope.opeCon = "输入订单号发货操作";
				ope.createtime = (new Date()).getTime();
				ope.orderNo = param.orderOutOrderNo;
				postJsonData("ope/addOpe", ope, res => {})
				renderCurrentPage()
			})
		}
		// 备注
		else if (field == "orderMark") {
			// 更新订单
			param1[field] = obj.value;
			updateOrder(param1, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}
		// 修改买断金额
		else if (field == "buyoutAmount") {
			// 更新订单
			param1[field] = parseInt(obj.value) * 100;
			updateOrder(param1, res => {
				var ope = {};
				ope.userId = admin.userId;
				ope.userNick = admin.userName;
				ope.opeCon = "修改订单买断金额操作";
				ope.createtime = (new Date()).getTime();
				ope.orderNo = param.orderOutOrderNo;
				postJsonData("ope/addOpe", ope, res => {})

				// 重新渲染表格
				renderCurrentPage()
			})
		}

	});
}

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 扣除赔偿金
		if (obj.event === 'deduct' && resData.orderStatus == 4) {
			layer.confirm(`确定扣除全部押金(${resData.attrDeposit/100}元)？`, {
				icon: 3,
				title: '提示',
				offset: '50%',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					// 扣除押金
					getData("pay/payRest", param, res => {
						layer.close(load);
						if (res.code == 0) {
							// 更新订单状态
							resData.orderStatus = 8;
							updateOrder(resData, res => {
								layer.msg('扣除成功', {
									icon: 1,
									time: 1500
								}, function() {
									// 操作成功添加操作记录
									var ope = {};
									ope.userId = admin.userId;
									ope.userNick = admin.userName;
									ope.opeCon = "扣除押金操作";
									ope.createtime = (new Date()).getTime();
									console.log("时间戳", ope.createtime);
									ope.orderNo = resData.orderOutOrderNo;
									postJsonData("ope/addOpe", ope, res => {

									})
									// 重新渲染表格
									renderCurrentPage();
									// refreshPage();
								});
							})

						} else {
							layer.msg(res.msg, {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
		// 解冻押金
		else if (obj.event === "unfreeze") {
			layer.confirm("确定解冻此押金？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					getData("pay/Reunfreeze", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('解冻成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 操作成功添加操作记录
								var ope = {};
								ope.userId = admin.userId;
								ope.userNick = admin.userName;
								ope.opeCon = "订单解冻操作";
								ope.createtime = (new Date()).getTime();
								ope.orderNo = resData.orderOutOrderNo;
								postJsonData("ope/addOpe", ope, res => {})
								// 更新订单状态
								// resData.orderStatus=1
								// updateOrder(resData,res=>{})
								// 重新渲染表格
								renderCurrentPage();
							});
						} else {
							layer.msg(res.msg || "解冻失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		} else if (obj.event === "manual") {
			layer.confirm("确定手动代扣超期金额吗？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					getData("pay/ManualDeduction", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('代扣成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 操作成功添加操作记录
								var ope = {};
								ope.userId = admin.userId;
								ope.userNick = admin.userName;
								ope.opeCon = "手动点击代扣操作";
								ope.createtime = (new Date()).getTime();
								ope.orderNo = resData.orderOutOrderNo;
								postJsonData("ope/addOpe", ope, res => {

								})
								renderCurrentPage();
							});
						} else if (res.code == 12) {
							layer.msg(res.msg || "代扣转支付失败", {
								icon: 2,
								time: 1500
							});
						} else if (res.code == 3) {
							layer.msg(res.msg || "数据为空", {
								icon: 2,
								time: 1500
							});
						} else {
							layer.msg(res.msg || "未知错误", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		} else if (obj.event === "firstRefund") {
			layer.confirm("确定退款首期扣款金额吗？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					getData("pay/refund", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('退款成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 操作成功添加操作记录
								var ope = {};
								ope.userId = admin.userId;
								ope.userNick = admin.userName;
								ope.opeCon = "退款第一期金额";
								ope.createtime = (new Date()).getTime();
								ope.orderNo = resData.orderOutOrderNo;
								postJsonData("ope/addOpe", ope, res => {

								})
								renderCurrentPage();
							});
						} else if (res.code == -2) {
							layer.msg(res.msg || "退款失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
	});

	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.orderNo = content;
		showTable("order/selectOrderByOrderNo", param, false)
	});


	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.tel = content;
		showTable("order/selectOrderByTel", param, false)
	});



	// 监听select
	form.on('select(chooseStatic)', function(data) {
		sortType = data.value;
		currentPage = 1;
		$("#searchInput").val("")
		renderCurrentPage();
	});
}

/**
 * 更新订单状态
 */
function updateOrder(resData, Callback) {
	postJsonData("order/updateOrder", resData, res => {
		Callback(res);
	})
}


/**
 * 重新渲染当前页的表格
 */
function renderCurrentPage() {
	var page = {
		curr: currentPage
	}
	// 全部订单
	if (sortType == -1 || sortType == "") showTable("order/selectOrders", {}, page)
	// 分类订单
	else {
		param = {}
		param.sortType = sortType
		showTable("order/selectOrderSortLayui", param, page)
	}
}
/**
 * 渲染表格
 */
function showTable(url, param, page) {

	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		size: 'lg',
		//toolbar: '#Exportbar',
		// defaultToolbar: [],
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		cols: [
			[ //表头
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'orderType',
					title: '订单类型',
					width: 150,
					sort: true,
					align: "center",
					templet: "#orderType"
				},
				{
					field: 'orderOperationId',
					title: '首期扣款单号',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'orderExpress',
					title: '快递单号(点击单元格可编辑)',
					width: 240,
					style: "color:red",
					align: "center",
					sort: true,
					edit: 'text'
				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					sort: true,
					width: 150,
				}, {
					field: 'orderAddr',
					title: '订单收货地址',
					width: 250,
					align: "center",
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					width: 180,
					sort: true,
					align: "center",
				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 120,
					sort: true,
					align: "center",
					templet: "#orderPrice"
				},
				{
					field: 'orderBeyondRent',
					title: '超期金额/元',
					width: 120,
					sort: true,
					align: "center",
					style: "color:red",
					templet: "#orderBeyondRent"
				},
				{
					field: 'attrDeposit',
					title: '商品押金',
					width: 200,
					sort: true,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center"
				},
				{
					field: 'goodsLeaseStart',
					title: '起租日期',
					width: 150,
					sort: true,
					align: "center",
					templet: "#goodsLeaseStart"
				},
				{
					field: 'goodsLeaseEnd',
					title: '第一次租赁归还日期',
					width: 180,
					sort: true,
					align: "center",
					templet: "#goodsLeaseEnd"
				},
				{
					field: 'keepRentEndTime',
					title: '续租截至日期',
					width: 150,
					sort: true,
					align: "center",
					templet: "#keepRentEndTime"
				},
				{
					field: 'leaseLimitDate',
					title: '租赁期限 (天)',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'leaseTerm',
					title: '已缴费的期数',
					width: 170,
					sort: true,
					align: "center",
					templet: function(d) {
						return d.leaseTerm + "期";
					}
				},
				{
					field: 'attrPrice',
					title: '该商品属性每天的租金(元)',
					width: 250,
					sort: true,
					align: "center",
					templet: "#attrPrice"
				},
				{
					field: 'orderLeave',
					title: '留言',
					align: "center",
					width: 200,
				}, {
					field: 'orderMark',
					title: '客服备注(点击单元格可编辑)',
					width: 240,
					style: "color:blue",
					align: "center",
					edit: 'text'
				}, {
					field: 'orderFinalpay',
					title: '最终付款(元)',
					align: "center",
					width: 150,
					sort: true,
					templet: "#orderFinalpay"
				},
				// {
				// 	field: 'buyoutAmount',
				// 	title: '买断金额(元)',
				// 	width: 270,
				// 	style: "color:red",
				// 	align: "center",
				// 	sort: true,
				// 	edit: 'text',
				// 	templet: "#buyoutAmount"
				// },
				{
					title: '状态/操作',
					align: "center",
					width: 380,
					fixed: "right",
					toolbar: '#orderStatus',
				},
			]
		],

	});

}
