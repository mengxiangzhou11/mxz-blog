var orderOutOrderNo = JSON.parse(getSession("orderOutOrderNo"))
var $, table, layer, form;
var param = {};
var sortType = "";
var currentPage;
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	form = layui.form;
 	
	$('.demoTable .layui-btn').on('click', function() {
		var type = $(this).data('type');
		active[type] ? active[type].call(this) : '';
	});
	param = {};
	param.orderOutorderno=orderOutOrderNo
	console.log(param)
	showTable("tranRecord/searchListByOrderOutorderno", param, true)

});

function showTable(url, param, page) {

	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		// defaultToolbar: [],
		parseData: function(res) { //res 即为原始返回的数据
			console.log(res)
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},

		cols: [
			[ //表头
				{
					field: 'tranRecordId',
					title: '序号',
					width: 120,
					sort:true,
					align: "center"
				},
				{
					field: 'orderOutorderno',
					title: '订单的编号',
					width: 150,
					align: "center",
					sort:true,
				},
				{
					field: 'operationId',
					title: '交易流水号',
					align: "center",
				}, {
					field: 'amount',
					title: '交易金额',
					align: "center",
					sort:true,
					width: 120,
					templet: "#money"
				}, {
					field: 'note',
					title: '备注',
					width: 250,
					align: "center",
				},
				{
					field: 'createtime',
					title: '支付时间',
					width: 150,
					sort:true,
					align: "center",
					templet: "#time"
				},
				
				{
					field: 'status',
					title: '状态',
					width: 120,
					align: "center",
					templet: "#status"
				},
					
			]
		],

	});

}
