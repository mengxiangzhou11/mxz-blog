var form, $, upload;
var admin = getSession("admin");
admin = JSON.parse(admin);
layui.use(['upload', 'form'], function() {
	$ = layui.jquery;
	var form = layui.form,
		layer = layui.layer;

	//监听提交
	form.on('submit(save)', function(data) {
		if (data.field.oldpass != admin.userPass) {
			layer.msg("旧密码不正确", {
				icon: 2,
				time: 1500 //2秒关闭（如果不配置，默认是3秒）
			});
			return;
		}
		if (data.field.newpass != data.field.repass) {
			layer.msg("新密码与确认密码不一致", {
				icon: 2,
				time: 1500 //2秒关闭（如果不配置，默认是3秒）
			});
			return;
		}
		let param = {
			userName: admin.userName,
			old: data.field.oldpass,
			newPass: data.field.newpass,

		}
		postFormData('login/resetPass', param, res => {
			if (res.code == 0) {
				layer.msg("修改成功", {
					icon: 1,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function(index) {
					layer.close(index);
					top.location.replace('../login.html');
					clearSession("admin");
					clearSession('token')
				});
			} else {
				layer.msg(res.msg || '修改失败', {
					icon: 2,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function() {});
			}


		})
	});


});
