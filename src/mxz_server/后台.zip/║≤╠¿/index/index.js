/**
 * 角色
 * root
 * admin
 * dister  经销商
 * operator 运营员
 */

layui.use('laytpl', function() {
	var admin = getSession("admin");
	var param = {};
	if (admin != null) {
		admin = JSON.parse(admin);
	}
	var adminName = admin.userName;
	// var roleTitle = admin.roleTitle;
// 	console.log(admin.userId);
// 	console.log(admin.userName);
	$('#admin_name').text(adminName);

	/* 获取当前用户的角色 */
	(function getRole() {
		let param = {
			userId: admin.userId
		}
		getData("role/getRoles", param, res => {
			check_role(res.data);
		})
	})()


	/*判断权限*/
	function check_role(role) {
		$('.nav-li').each(function() {
			if (null != $(this).attr("class")) {
				var roleArr = $(this).attr("class").split(" ");
				let isHas = false;
				for (var i in role) {
					if (roleArr.indexOf(role[i].roleTitle) != -1) {
						isHas = true;
					}
				}
				if (!isHas) $(this).remove();

			} else {
				$(this).remove();
			}
		})
	}
})
