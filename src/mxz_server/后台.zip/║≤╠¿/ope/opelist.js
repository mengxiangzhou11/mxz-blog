var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;
	//插入表格数据
	table.render({
		elem: '#opeList',
		url: ip + 'ope/searchListOpe', //数据接口
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location='../login.html';
			}
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
		},
		size: 'lg',
		page: true, //开启分页
		id: 'all',
		cols: [
			[ //表头
				{
					field: 'opeId',
					title: '编号',
					width: 80,
					align: "center",
				}, {
					field: 'userId',
					title: '操作用户id',
					align: "center",
					width: 80,
				}, {
					field: 'userNick',
					title: '操作用户名',
					align: "center",
					width: 150
				}, {
					field: 'opeCon',
					title: '操作内容描述',
					align: "center",
					width: 250,
				}, {
					field: 'orderNo',
					title: '对应订单号',
					align: 'center',
					width: 250,
				} ,{
					field: 'createtime',
					title: '操作时间',
					align: "center",
					templet:function(d){
						return formatDate(parseInt(d.createtime))
					}
				}, 
			]
		]
	});
		
	
});

