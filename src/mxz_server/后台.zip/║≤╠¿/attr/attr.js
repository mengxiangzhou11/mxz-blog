var $, layer, form, table;
var goodsId = getUrlParam("goodsId")
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;
	table = layui.table;
	/**
	 * 滚动到顶部
	 */
	// window.parent.scrollTo(0, 0);
	window.scrollTo(0, 0);

	//插入表格数据
	showTable();
	//监听行工具事件
	watchToolBar();


});


/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(userTable)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 编辑
		if (obj.event === 'toEdit') {
			setSession("attr", JSON.stringify(resData))
			x_admin_show_all('修改属性', './editAttr.html');
		}
		// 添加
		if (obj.event === 'toAdd') {
			toOtherPage('./addAttr.html?goodsId=' + goodsId)
			// x_admin_show_all('添加属性', './addAttr.html?goodsId=' + goodsId);
		}
		// 删除商品
		if (obj.event === 'del') {
			param = {};
			// param.attrId = resData.attrId;
			deleteTableFun(obj, `attr/hideAttr?attrId=${resData.attrId}`, param, "确定删除此属性")
		}
	});

}


function toAdd() {
	toOtherPage('./addAttr.html?goodsId=' + goodsId)
	// x_admin_show_all('添加属性', './addAttr.html?goodsId=' + goodsId);
}


/**
 * 渲染表格
 */
function showTable() {
	table.render({
		elem: '#userTable',
		url: ip + 'goods/selectGoodsById', //数据接口
		where: {
			goodsId: goodsId
		},
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			return {
				"code": res.code, //解析接口状态
				"data": res.data.attrs //解析数据列表
			};
		},
		size: 'lg',
		page: false, //开启分页
		cols: [
			[ //表头
				{
					field: 'attrTitle',
					title: '属性名称',
					width: 200,
					align: "center",
				}, {
					field: 'attrPrice',
					title: '属性价格(元/天)',
					align: "center",
					width: 150,
					sort: true,
					templet: '#attrPrice'
				}, {
					field: 'attrRestprice',
					title: '属性押金(元)',
					align: "center",
					width: 150,
					sort: true,
					templet: '#attrRestprice'
				}, 
				{
					field: 'buyout',
					title: '买断价格(元)',
					align: "center",
					width: 150,
					sort: true,
					templet: '#buyout'
				}, 
				{
					field: 'attrNum',
					title: '库存',
					width: 80,
					sort: true,
					align: "center",
				},
				{
					field: 'leaseLimitDate',
					title: '租赁期数',
					width: 150,
					sort: true,
					align: "center",
					templet: '#leaseLimitDate'
				}, {
					field: 'pcircle',
					title: '扣款周期',
					width: 150,
					sort: true,
					align: "center",
				},
				{
					field: 'zwjs',
					title: '租完即送',
					width: 150,
					align: "center",
					templet: "#zwjs"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 250,
					align: "center"
				}
			]
		]

	});


}
