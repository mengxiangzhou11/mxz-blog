var $, layer, form, upload;
var form;
var attr = JSON.parse(getSession("attr"));
// var leaseLimitPrice="";
var value = 0;
var attrRentday = attr.leaseLimitDate.split(',');
clearSession("attr")
// var attrRentday = []; //租期
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;
	showForm();
	renderSelTena()
	watchSelTena();
	//监听提交
	toSubmit();

});


/**
 * 渲染表单
 */
function showForm() {
	form.val("titleForm", {
		"attrTitle": attr.attrTitle, // "name": "value"
		"attrPrice": attr.attrPrice / 100, // "name": "value"
		"buyout": attr.buyout / 100, // "name": "value"
		"attrRestprice": attr.attrRestprice / 100, // "name": "value"
		"attrNum": attr.attrNum, // "name": "value"
		// "leaseLimitDate":attr.leaseLimitDate,
		"pcircle": attr.pcircle,
		"zwjs": attr.zwjs,
	})

}

function toSubmit() {
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.attrPrice = parseInt(param.attrPrice * 100) //商品属性价格 要与押金商品一致
		param.attrRestprice = parseInt(param.attrRestprice * 100) //商品属性押金 
		param.buyout = parseInt(param.buyout * 100) //买断金额
		if (attrRentday.length < 1 || attrRentday.length > 3) {
			layer.msg('租赁周期至少选择一个,至多选择三个', {
				icon: 2,
				fixed: false,
				scrollbar: false
			});
			return;
		}
		param.leaseLimitDate = attrRentday.join(',');
		var submitData = Object.assign(attr, param);
		postFormData("attr/updateAttr", submitData, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				}, function() {
					parent.location.reload();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})

	});
}


/* 渲染租期 */
function renderSelTena() {
	$("#selTena").empty();
	if (!attrRentday) return
	for (var i = 0; i < attrRentday.length; i++) {
		let value = attrRentday[i] >= 30 ? attrRentday[i] / 30 + "个月" : attrRentday[i] + "天"
		let temp =
			`<span class="layui-btn layui-btn-primary label-item" data-index='${[i]}'>
				${value}
				<i class="delete-lable layui-icon layui-icon-close-fill"></i>
			 </span>`
		$("#selTena").append(temp);
		form.render();
		$(".label-item").on('click', function() {
			let that = $(this);
			let labelIndex = $(this).data('index');
			layer.confirm('确定删除此租期?', {
				icon: 3,
				title: '提示',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					attrRentday.splice(labelIndex, 1)
					layer.close(index);
					that.remove();
					renderSelTena()
				}
			});
		})
	}
}


/* 渲染选择的租期 */
function watchSelTena() {
	form.on('select(selectTena)', function(data) {
		let value = data.elem[data.elem.selectedIndex].text;
		let day = data.value;
		attrRentday.push(day)
		renderSelTena()
		if (!value) return
	});
}
