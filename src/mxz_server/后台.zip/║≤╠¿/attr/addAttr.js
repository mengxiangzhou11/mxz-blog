var $, layer, form;
var goodsId = getUrlParam("goodsId")
var leaseLimitPrice = "";
var value = 0;
var attrRentday = []; //租期
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;

	//监听提交
	toSubmit();
	watchSelTena()

});


/**
 * 表单提交
 */
function toSubmit() {
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.goodsId = goodsId;
		param.attrPrice = parseInt(param.attrPrice * 100); //商品属性价格 要与押金商品一致
		param.attrRestprice = parseInt(param.attrRestprice * 100); //商品属性押金
		param.buyout = parseInt(param.buyout * 100); //买断金额
		if (attrRentday.length < 1 || attrRentday.length > 3) {
			layer.msg('租赁周期至少选择一个,至多选择三个', {
				icon: 2,
				fixed: false,
				scrollbar: false
			});
			return;
		}
		param.leaseLimitDate = attrRentday.join(',');
		postFormData('attr/insertAttr', param, res => {
			if (res.code == 0) {
				var index = layer.open({
					content: '添加成功',
					btn: ['继续添加', '取消'],
					yes: function(index, layero) {
						// 清空表单
						$("#form1")[0].reset();
						layui.form.render()
						layer.close(index)
					},
					btn2: function(index, layero) {
						toOtherPage('../attr/attr.html?goodsId=' + goodsId)
					},
					cancel: function(index, layero) {
						toOtherPage('../attr/attr.html?goodsId=' + goodsId)
					}
				});
			} else {
				layer.msg('增加失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});

}

/* 监听选择租期,渲染选择的租期 */
function watchSelTena() {
	form.on('select(selectTena)', function(data) {
		let value = data.elem[data.elem.selectedIndex].text;
		let day = data.value;
		attrRentday.push(day)
		if (!value) return
		let temp =
			`<span class="layui-btn layui-btn-primary label-item" data-index='${value}'>
				${value}
				<i class="delete-lable layui-icon layui-icon-close-fill"></i>
			 </span>`
		$("#selTena").append(temp);

		$(".label-item").on('click', function() {
			let that = $(this);
			let labelIndex = $(this).data('index');
			layer.confirm('确定删除此租期?', {
				icon: 3,
				title: '提示',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					attrRentday.splice(labelIndex, 1)
					layer.close(index);
					that.remove();
				}
			});
		})
	});
}
