var $, layer, form, table;
var param = JSON.parse(getSession("param"));
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;
	table = layui.table;
	initParamForm(param);
});


const initParamForm = (param) => {
	let q = $('#paramForm');
	q.empty();
	let str;
	for (var i = 0; i < 5; i++) {
		if (i == 0) {
			str = getTemplate(i);
		}
		else{
			str+=getTemplate(i);
		}
	}
	q.append(str);
	form.render()
}
/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(userTable)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 编辑
		if (obj.event === 'toEdit') {
			setSession("attr", JSON.stringify(resData))
			x_admin_show_all('修改属', './editParam.html');
		}
		// 添加
		if (obj.event === 'toAdd') {
			toOtherPage('./addParam.html?goodsId=' + goodsId)
			// x_admin_show_all('添加属性', './addAttr.html?goodsId=' + goodsId);
		}
		// 删除商品
		if (obj.event === 'del') {
			param = {};
			// param.attrId = resData.attrId;
			deleteTableFun(obj, `attr/hideAttr?attrId=${resData.attrId}`, param, "确定删除此属性")
		}
	});

}


function toAdd() {
	toOtherPage('./addAttr.html?goodsId=' + goodsId)
	// x_admin_show_all('添加属性', './addAttr.html?goodsId=' + goodsId);
}


const getTemplate = (index) => {
	return `<div style="padding: 20px;border:1px solid #E1E1E8">
					<div style="text-align: right;padding-bottom: 10px;">
						<a class="layui-btn  layui-btn-sm layui-btn-danger" onclick="delItem(${index})">删除</a>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">参数名</label>
						<div class="layui-input-block">
							<input type="text" name="paramKey${index}" required lay-verify="required" placeholder="请输入参数名" autocomplete="off" class="layui-input">
						</div>
					</div>
					<div class="layui-form-item">
						<label class="layui-form-label">参数值</label>
						<div class="layui-input-block">
							<input type="text" name="paramValue${index}" required lay-verify="required" placeholder="请输入参数值" autocomplete="off"
							 class="layui-input">
						</div>
					</div>
				</div>`
}
