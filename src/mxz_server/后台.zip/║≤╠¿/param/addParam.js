var $, layer, form;
var goodsId = getUrlParam("goodsId")
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;

	//监听提交
	toSubmit();

});


/**
 * 表单提交
 */
function toSubmit() {
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.goodsId = goodsId;
		param.attrPrice = parseInt(param.attrPrice * 100);
		param.attrRestprice = parseInt(param.attrRestprice * 100);
		postFormData('attr/insertAttr', param, res => {
			if (res.code == 0) {
				var index = layer.open({
					content: '添加成功',
					btn: ['继续添加', '取消'],
					yes: function(index, layero) {
						// 清空表单
						$("#form1")[0].reset();
						layui.form.render()
						layer.close(index)
					},
					btn2: function(index, layero) {
						toOtherPage('../attr/attr.html?goodsId=' + goodsId)
					},
					cancel: function(index, layero) {
						toOtherPage('../attr/attr.html?goodsId=' + goodsId)
					}
				});
			} else {
				layer.msg('增加失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})

	});

}
