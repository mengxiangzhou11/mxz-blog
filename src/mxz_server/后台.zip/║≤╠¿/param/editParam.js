var $, layer, form, upload;
var form;
var attr = JSON.parse(getSession("attr"));
clearSession("attr")
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;
	showForm();

	//监听提交
	toSubmit();

});

/**
 * 渲染表单
 */
function showForm() {
	form.val("titleForm", {
		"attrTitle": attr.attrTitle, // "name": "value"
		"attrPrice": attr.attrPrice / 100, // "name": "value"
		"attrRestprice": attr.attrRestprice / 100, // "name": "value"
		"attrNum": attr.attrNum // "name": "value"
	})

}

function toSubmit() {
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.attrPrice = parseInt(param.attrPrice * 100)
		param.attrRestprice = parseInt(param.attrRestprice * 100)
		var submitData = Object.assign(attr, param)
		postFormData("attr/updateAttr", submitData, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				}, function() {
					parent.location.reload();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});

}
