var $, layer, upload;
var form;
var classfyCover;
var allData = JSON.parse(getSession("editParam"))
clearSession("editParam")
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;

	showForm();

	uploadImg();
	//监听提交
	toSubmit();

});

function toSubmit() { //监听提交
	form.on('submit(submit)', function(data) {
		var param = data.field;
		allData.classfyTitle = param.classfyTitle
		allData.classfyCover = classfyCover;
		allData.minPrice = param.minPrice * 100;
		postJsonData("classfy/updateClassfy", allData, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time: 1500,
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
	});


}

/**
 * 渲染表单
 */
function showForm() {
	// 渲染图片
	if (allData.classfyCover) {
		classfyCover = allData.classfyCover;
		$('#fengmian').attr('src', ip + classfyCover);
	}
	form.val("titleForm", {
		"classfyTitle": allData.classfyTitle,
		"minPrice": allData.minPrice / 100
	})

}

/**
 * 单张图片上传
 */
function uploadImg() {
	//普通图片上传
	var load1;
	var uploadInst = upload.render({
		elem: '#uploadImg',
		url: ip + 'util/multipartUploads',
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			load1 = layer.load(0, {
				offset: '50%',
				fixed: false,
			});
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				$('#fengmian').attr('src', result); //图片链接（base64）
			});
		},
		data: {
			path: "good/"
		},
		done: function(res) {
			layer.close(load1);
			if (res.code == 401) {
				top.location = '../login.html';
			}
			//如果上传失败
			if (res.code == 0) {
				classfyCover = res.data.urls[0]
			}
			if (res.code > 0) {
				return layer.msg('上传失败');
			}
			//上传成功
		},
		error: function() {
			//演示失败状态，并实现重传
			var demoText = $('#demoText');
			demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
			demoText.find('.demo-reload').on('click', function() {
				uploadInst.upload();
			});
		}
	});

}
