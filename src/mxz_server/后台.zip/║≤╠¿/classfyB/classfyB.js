var $, table;
var param = {};
var classfyId = getUrlParam("classfyId");
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;


	// 获取数据

	showTable()



	//监听行工具事件
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var objData = obj.data
		param = {}
		param = obj.data;
		setSession("editParam", JSON.stringify(param))
		// 跳转到修改
		if (obj.event === 'toEdit') {
			x_admin_show_all('修改二级导航名称', './editClassfyBTitle.html');
		}
		// 跳转到添加
		if (obj.event === 'toAdd') {
			x_admin_show_all('添加二级导航', './addClassfyBTitle.html?classfyId=' + classfyId);
		}
		// 删除
		if (obj.event === 'del') {
			param = {};
			param.classfyId = objData.classfyId
			deleteTableFun(obj, "classfy/deleteClassfy", param, "确定删除此导航")

		}
		// 跳转到下级分类
		if (obj.event === 'toGoods') {
			x_admin_show_all('商品', '../goods/goods.html?classfyId=' + param.classfyId);
		}
	});


});

/**
 * 跳转至添加二级导航
 */
function toAdd() {
	x_admin_show_all('添加二级导航', './addClassfyBTitle.html?classfyId=' + classfyId);
}

/**
 * 渲染表格
 */
function showTable(pid) {
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 350,
		url: ip + 'classfy/selectClassfies', //数据接口  
		headers: {
			token: getSession("token")
		},
		page: false,
		size: 'lg',
		where: {
			pid: classfyId
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [
			[ //表头
				{
					field: 'classfyTitle',
					title: '二级导航名称',
					width: 250,
					align: "center"
				}, {
					title: '封面图',
					toolbar: '#classfyCover',
					align: "center"
				},
				{
					title: '最低价格(用作显示)',
					align: "center",
					sort: true,
					templet: '#minPrice',
				},
				{
					title: '商品',
					toolbar: '#good',
					align: "center"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 300,
					align: "center"
				}
			]
		]

	});
}
