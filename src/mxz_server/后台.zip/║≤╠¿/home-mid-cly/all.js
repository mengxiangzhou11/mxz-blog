var $, table;
var param = {};
var classfyId = getUrlParam("classfyId");
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;


	// 获取数据

	showTable()



	//监听行工具事件
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var objData = obj.data
		setSession("editParam", JSON.stringify(objData))
		// 跳转到修改
		if (obj.event === 'toEdit') {
			x_admin_show('修改', './edit.html');
		}
		
	});


});


/**
 * 渲染表格
 */
function showTable(pid) {
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 350,
		url: ip + 'classfy/selectClassfies', //数据接口  
		headers: {
			token: getSession("token")
		},
		page: false,
		size:'lg',
		where: {
			pid: 0
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			var data = res.data.slice(0, 6);
			return {
				"code": res.code, //解析接口状态
				"data": data //解析数据列表
			}


		},
		cols: [
			[ //表头
				{
					field: 'classfyTitle',
					title: '二级导航名称',
					width: 250,
					align: "center"
				}, {
					field: 'classfyTitle',
					title: '二级标题(括号内的)',
					width: 250,
					templet: '#two',
					align: "center"
				}, {
					field: 'classfyCover',
					title: '图标',
					templet: '#classfyCover',
					align: "center"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 300,
					align: "center"
				}
			]
		]

	});
}
