var $, table, layer, form;
var param = {};
var currentPage;
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	form = layui.form;


	// 获取数据，渲染表格
	param = {};
	showTable("order/selectOrders", param, true)


	//监听行工具事件
	watchToolBar();

	// 监听输入单号
	watchEdit();



});

function watchEdit() {
	table.on('edit(list)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		var param = obj.data;
		param[obj.field] = obj.value;
		if (param.orderStatus == 7) {
			if (!obj.value) {
				param.orderStatus = 7;
			} else {
				param.orderStatus = 2;
			}
		}
		// 更新订单
		updateOrder(param, res => {
			// 重新渲染表格
			var page = {
				curr: currentPage
			}
			if (sortType == -1 || sortType == "") showTable("order/selectOrders", {}, page)
			else {
				param = {}
				param.sortType = sortType
				showTable("order/selectOrderSortLayui", param, page)
			}
		})
	});
}

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 扣除赔偿金
		if (obj.event === 'deduct') {
			layer.confirm("确定解冻此押金？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					console.log("解冻押金的参数",param)
					getData("pay/unfreeze", param, res => {
						console.log("解冻押金返回的",res)
						layer.close(load);
						if (res.code == 0) {
							layer.msg('解冻成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 更新订单状态
								// resData.orderStatus=1
								// updateOrder(resData,res=>{})
								// 重新渲染表格
								var page = {
									curr: currentPage
								}
								showTable("reorder/selectReorderLay", {}, page)
							});
						} else {
							layer.msg(res.msg || "解冻失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});


		}
	});

	//监听提交--搜索单号
	form.on('submit(toSubmit)', function(data) {
		var content = data.field.content;
		param = {}
		param.orderNo = content;
		showTable("order/selectOrderByOrderNo", param, false)
	});
}

/**
 * 更新订单状态
 */
function updateOrder(resData, Callback) {
	postJsonData("order/updateOrder", resData, res => {
		Callback(res);
	})

}
/**
 * 渲染表格
 */
function showTable(url, param, page) {

	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		size: 'lg',
		defaultToolbar: [],
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				data[0] = res.data
				return {
					"data": data,
					"code": res.code
				}

			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		cols: [
			[ //表头
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					align: "center"
				},
				{
					field: 'orderExpress',
					title: '快递单号(点击单元格可编辑)',
					width: 240,
					style: "color:red",
					align: "center",
					edit: 'text'
				},
				// 				{
				// 					field: 'orderOutRequestNo',
				// 					title: '流水号',
				// 					align: "center",
				// 					width: 180,
				// 				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					width: 150,
				}, {
					field: 'orderAddr',
					title: '订单收货地址',
					width: 250,
					align: "center",
				},
				// 				{
				// 					field: 'orderType',
				// 					title: '订单类型',
				// 					width: 150,
				// 					align: "center",
				// 					templet: '#orderType'
				// 				},
				// 				{
				// 					field: 'orderCreatime',
				// 					title: '下单时间',
				// 					width: 200,
				// 					align: "center",
				// 				}, 
				// 				{
				// 					field: 'orderPaytime',
				// 					title: '付款时间',
				// 					width: 200,
				// 					align: "center",
				// 				},
				// 				{
				// 					field: 'goodsCover',
				// 					title: '商品封面',
				// 					width: 150,
				// 					align: "center",
				// 					templet: '#img1'
				// 				},
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 200,
					align: "center",
					templet: "#orderPrice"
				},
				{
					field: 'attrDeposit',
					title: '商品押金',
					width: 200,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center"
				},
				{
					field: 'goodsLeaseStart',
					title: '起租日期',
					width: 150,
					align: "center"
				},
				{
					field: 'goodsLeaseEnd',
					title: '结束日期',
					width: 150,
					align: "center"
				}, {
					field: 'goodsTotalRuntal',
					title: '总租赁时长(天)',
					width: 200,
					align: "center"
				},
				// 				{
				// 					field: 'attrPrice',
				// 					title: '该商品属性每天的租金(元)',
				// 					width: 250,
				// 					align: "center",
				// 					templet: "#attrPrice"
				// 				},
				{
					field: 'orderLeave',
					title: '留言',
					align: "center",
					width: 300,
				}, {
					field: 'orderFinalpay',
					title: '最终付款(元)(不含押金)',
					align: "center",
					width: 270,
					templet: "#orderFinalpay"
				}, {
					title: '状态',
					align: "center",
					width: 200,
					fixed: "right",
					toolbar: '#orderStatus',
				},
				// 				{
				// 					title: '操作',
				// 					toolbar: '#tool',
				// 					fixed: "right",
				// 					width: 180,
				// 					align: "center"
				// 				},
			]
		]

	});

}
