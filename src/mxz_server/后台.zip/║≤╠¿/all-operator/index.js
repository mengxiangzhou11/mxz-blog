var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;
	//插入表格数据
	table.render({
		elem: '#roleTable',
		url: ip + 'user/getList', //数据接口
		toolbar: '#toolbarDemo',
		defaultToolbar: [],
		where: {
			roleId: 4
		},
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
		},
		size: 'lg',
		page: true, //开启分页
		cols: [
			[ //表头
				{
					field: 'userName',
					title: '用户',
					width: 200,
					align: "center",
					sort: true
				}, {
					field: 'adminName',
					title: '登录账号',
					align: "center",
					width: 180,
					sort: true,
				}, {
					field: 'adminPass',
					title: '登录密码',
					align: "center",
					width: 180,
					sort: true,
				}, {
					field: 'userBalance',
					title: '余额(元)',
					align: "center",
					width: 180,
					sort: true,
					templet: function(d) {
						return d.userBalance / 100 + "元";
					}
				}, {
					field: 'agent',
					title: '是否代理商',
					align: "center",
					width: 150,
					sort: true,
					templet: function(d) {
						return d.agent == 0 ? "否" : "是"
					}
				}, {
					field: 'lastLoginTime',
					title: '最后一次登录时间',
					align: "center",
					sort: true
				}, {
					title: '操作',
					align: "center",
					fixed: "right",
					width: 200,
					templet: "#setDister"
				}
			]
		]
	});

	//监听事件
	table.on('toolbar(roleTable)', function(obj) {
		var checkStatus = table.checkStatus(obj.config.id);
		switch (obj.event) {
			/* 添加经销商 */
			case 'setDister':
				x_admin_show("添加运营员", "../user/user.html?isForm=operator")
				break;
		};
	});

	watchTool();
	//监听工具条 
	function watchTool() {
		table.on('tool(roleTable)', function(obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
			var data = obj.data; //获得当前行数据
			var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
			var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
			let userId = data.userId;
			let param = {
				userId
			}
			//取消授权经销商
			if (layEvent === 'removeDister') {
				layer.confirm('确定取消授权当前用户为经销商?', {
					icon: 3,
					title: '提示'
				}, function(index) {
					removeRole("userRole/degrantOperatorr", param)
					layer.close(index);
				});
			}
		});
	}

	/* 取消 */
	function removeRole(url, param) {
		getData(url, param, res => {
			if (res.code == 0) {
				layer.msg("取消授权成功", {
					icon: 1,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function() {
					table.reload('roleTable');
				});
			} else {
				layer.msg(res.msg || '取消授权失败', {
					icon: 2,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function() {});
			}
		})
	}

});
