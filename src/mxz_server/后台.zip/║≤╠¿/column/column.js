﻿var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;

	table.render({
		elem: '#column',
		// height: 350,
		url: ip + 'icon/selectCommonIcons', //数据接口         
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			var data=res.data;
			for(var i=0;i<4;i++){
				data[i].detailSrcs=data[i+5].iconSrc
			}
			return {
				"code": res.code, //解析接口状态
				"data": data.slice(0, 4) //解析数据列表
			}

		},
		page: false, //开启分页
		cols: [
			[ //表头
				{
					field: 'iconTitle',
					title: '栏目名称',
					width: 400,
					align: "center"
				}, {
					field: 'iconSrc',
					title: '栏目封面图（建议格式127*127）',
					templet: '#img',
					align: "center"
				}, {
					field: 'detailSrcs',
					title: '栏目详细图',
					templet: '#detailSrcs',
					align: "center"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 250,
					align: "center"
				}
			]
		]

	});


	//监听行工具事件
	table.on('tool(column)', function(obj) {
		var data = obj.data;
		var currentIndex = $("tr").index(obj.tr) - 1;
		// 跳转到详细
		if (obj.event === 'toEdit') {
			x_admin_show_all('详情', './editColumn.html?currentIndex=' + currentIndex);
		}
	});




});
