var $;
var param = {};
var imgs = [];
var fengmian;
var iconData;
var currentIndex = getUrlParam("currentIndex");
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;
	var form = layui.form;



	// 获取轮播
	getData("icon/selectCommonIcons", {}, res => {
		if (res.code == 0) {
			iconData = res.data
			// 表单初始化
			showForm(form, res.data)
			var iconSrc = res.data[4].iconSrc;
		}
	})



	//普通图片上传
	var load1;
	var uploadInst = upload.render({
		elem: '#uploadImg',
		url: ip + 'util/multipartUploads',
		before: function(obj) {
			load1 = layer.load(0, {
				offset: '50%',
				fixed: true,
			});
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				$('#fengmian').attr('src', result); //图片链接（base64）
			});
		},
		headers: {
			token: getSession("token")
		},
		data: {
			path: "icon/"
		},
		done: function(res) {
			layer.close(load1);
			if (res.code == 401) {
				top.location = '../login.html';
			}
			//如果上传失败
			if (res.code == 0) {
				fengmian = res.data.urls[0]
			}
			if (res.code > 0) {
				return layer.msg('上传失败');
			}
			//上传成功
		},
		error: function() {
			//演示失败状态，并实现重传
			var demoText = $('#demoText');
			demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
			demoText.find('.demo-reload').on('click', function() {
				uploadInst.upload();
			});
		}
	});



	//多图片上传
	var load;
	upload.render({
		elem: '#uploadsImg',
		url: ip + 'util/multipartUploads',
		multiple: true,
		data: {
			path: "banner/"
		},
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			load = layer.load(0, {
				offset: '50%',
				fixed: true,
			});
			//预读本地文件示例，不支持ie8
		},
		done: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.code == 0) {
				imgs.push(res.data.urls[0])
			}
		},
		allDone: function(res) {
			layer.close(load);
			showImg()

		},
	});


	//监听提交
	var load2;
	form.on('submit(submit)', function(data) {
		load2 = layer.load(0, {
			offset: '50%',
			fixed: true,
		});
		var param = data.field;
		iconData[currentIndex].iconTitle = data.field.iconTitle
		iconData[currentIndex].iconSrc = fengmian
		var detailIndex = parseInt(currentIndex) + 5;
		iconData[detailIndex].iconSrc = imgs.join(",")
		postJsonData("icon/updateIcon", iconData[currentIndex], res => {
			layer.close(load2);
			if (res.code == 0) {
				load2 = layer.load();
				postJsonData("icon/updateIcon", iconData[detailIndex], res1 => {
					layer.close(load2);
					if (res1.code == 0) {
						layer.msg('修改成功', {
							icon: 1,
							time: 1500,
							offset: '50%',
							fixed: true,
						}, function() {
							parent.location.reload();
							x_admin_close();
						});
					} else {
						layer.msg('修改失败', {
							icon: 2
						});
					}
				})
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
	});
});

// 渲染图片到页面
function showImg() {
	var all;
	for (var i = 0; i < imgs.length; i++) {
		var temp = '<img onclick="deleteImg(' + i + ')" src="' + ip + imgs[i] + '" class="layui-upload-img my-img">';
		if (!all) {
			all = temp
		} else {
			all += temp;

		}
	}

	$("#showImgs").empty();
	$('#showImgs').append(all)
}

// 点击删除图片
function deleteImg(i) {
	layer.confirm('确定删除此图片?', {
		icon: 3,
		title: '提示',
		offset: '50%',
		fixed: false,
		scrollbar: false,
		yes: function(index, layero) {
			//do something
			imgs.splice(i, 1);
			showImg();
			layer.msg('删除成功', {
				icon: 1,
			});
		}
	});
}

/**
 * 渲染表单
 */
function showForm(form, data) {
	// 封面图片
	fengmian = data[currentIndex].iconSrc
	$('#fengmian').attr('src', ip + fengmian); //图片链接（base64）
	form.val("columnForm", {
		"iconTitle": data[currentIndex].iconTitle // "name": "value"
	})

	// 详细图片渲染]
	var detailIndex = parseInt(currentIndex) + 5;
	if (data[detailIndex].iconSrc) {
		imgs = data[detailIndex].iconSrc.split(",");
		showImg();
	}
}
