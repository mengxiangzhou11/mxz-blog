var url = parent.url;
var form, $, upload;
var phoneData;
var wechatData;
var addressData;
var monDayData
layui.use(['upload', 'form'], function() {
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;

	// 获取数据
	getAllValue()

	toSubmit("addressForm")

	toSubmit("phoneForm")

	toSubmit("wechatForm")
	
	toSubmit("monDayForm")


});

/**
 * 获取数据
 * 渲染表单
 */
function getAllValue() {
	getData('icon/selectCommonIcons', {}, res => {
		let value = res.data;
		addressData = value[15];
		wechatData = value[16];
		phoneData = value[17];
		form.val('addressForm', {
			"value": addressData.iconSrc,
		})
		form.val('phoneForm', {
			"value": phoneData.iconSrc,
		})
		form.val('wechatForm', {
			"value": wechatData.iconSrc,
		})
	})
	getData('icon/getDefaultDist', {}, res => {
		monDayData=res.data[0]
		form.val('monDayForm', {
			"value": monDayData.iconSrc,
		})
	})
	
}


/*提交表单*/
function toSubmit(btnFilter) {
	//监听提交
	form.on(`submit(${btnFilter})`, function(data) {
		var value = data.field.value;
		let param;
		if (btnFilter == 'addressForm') param = addressData
		else if (btnFilter == 'phoneForm') param = phoneData
		else if (btnFilter == 'wechatForm') param = wechatData
		// else if (btnFilter == 'monDayForm') param = monDayData
				else if (btnFilter == 'monDayForm') {
					if (value < 1) {
						layer.msg("天数不能少于一天", {
							icon: 2,
							time: 1000
						})
						return;
					}
					param = monDayData
				}
		param.iconSrc = value
		postJsonData("icon/updateIcon", param, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});
}
