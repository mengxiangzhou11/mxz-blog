var $, layer, upload, form, layedit;
var form;
var extra = JSON.parse(getSession("extra"));
console.log(extra)
clearSession("extra")
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;

	var load;
	// load = layer.load(0, {
	// 	offset: '50%',
	// 	fixed: false,
	// 	scrollbar: false,
	// });
	toSubmit();
	
	showForm();
});


/**
 * 渲染表单
 */
function showForm() {
	form.val("goodForm", {
		"extraDesc": extra.extraDesc, 
		"extraTitle": extra.extraTitle,
	})

}


/**
 * 提交表单
 */
function toSubmit() {

	form.on('submit(submit)', function(data) {
		var load;
		let param = data.field;
		param.extraId=extra.extraId;
		console.log(param)
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
			scrollbar: false
		});
		postJsonData("extra/updateExtra", param, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				}, function() {
					parent.location.reload();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});
}


