var $, layer, upload, form, layedit;
var form;
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;

	var load;
	// load = layer.load(0, {
	// 	offset: '50%',
	// 	fixed: false,
	// 	scrollbar: false,
	// });
	toSubmit();
});


/**
 * 提交表单
 */
function toSubmit() {

	form.on('submit(submit)', function(data) {
		var load;
		var param = data.field;
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
			scrollbar: false
		});
		postJsonData("extra/insertQuestion", param, res => {
		if (res.code == 0) {
			layer.msg('添加成功', {
				icon: 1,
				offset: '[50%,50%]',
				fixed: true,
				time: 1500
			}, function() {
				parent.location.reload();
			});
		} else {
			layer.msg('添加失败', {
				icon: 2,
				offset: '[50%,50%]',
				fixed: true,
				time: 1500
			});
		}
		})
	});
}


