/**
 * 此页面可以从两个地方进入
 * 1、首页进入的，当前商品首页分类的商品
 * 2、商品分类进入的
 */
var $, table, layer, laytpl;
var param = {};
var classfyId = getUrlParam("classfyId");
var url = "goodsClassfy/selectGoods"; //请求商品的数据接口
var page = false; //是否分页

layui.use(['layer', 'jquery', 'table', 'laytpl'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	laytpl = layui.laytpl;


	// 获取数据
	showTable()


	//监听行工具事件
	watchToolBar();



});

/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 添加
		// if (obj.event === 'toAdd') {
		// 	x_admin_show_all_ref('添加商品', '../allGoods/allGoods.html?classfyId=' + classfyId);
		// }
		// 删除商品
		if (obj.event === 'del') {
			param = {};
			param.goodsId = resData.goodsId
			param.classfyId = classfyId
			deleteTableFun(obj, "goodsClassfy/deleteGoodsClassfy", param, "确定从此分类中删除该商品？")
		}
	});

}

/**
 * 跳转到添加商品
 */
function toAdd() {
	x_admin_show_all_ref('添加商品', '../allGoods/allGoods.html?classfyId=' + classfyId);
}

/**
 * 渲染表格
 */
function showTable() {
	var colList = [ //表头
		{
			field: 'goodsId',
			title: 'Id',
			width: 100,
			fixed:'left',
			align: "center",
		},
		{
			field: 'goodsTitle',
			title: '商品名称',
			width: 250,
			align: "center"
		}, {
			field: 'goodsDesc',
			title: '商品描述',
			align: "center",
			width: 300,
		}, {
			title: '商品属性',
			align: "center",
			toolbar: '#attr',
			width: 300,
		}, {
			field: 'goodsCover',
			title: '商品封面图',
			width: 120,
			align: "center",
			templet: '#img1'
		}, {
			field: 'goodsBanner',
			title: '商品轮播图',
			width: 250,
			align: "center",
			templet: '#img2'
		}, {
			field: 'goodsIntroduce',
			title: '商品介绍图',
			width: 250,
			align: "center",
			// templet: '#img3'
		}, {
			field: 'goodsParameter',
			title: '租赁流程图',
			width: 250,
			align: "center",
			// templet: '#img4'
		}, {
			field: 'goodsTip',
			title: '租赁必读图',
			width: 250,
			align: "center",
			// templet: '#img5'
		},  {
			field: 'goodsPackPrice',
			title: '本店活动',
			width: 180,
			align: "center",
		}, {
			field: 'goodsSaleNum',
			title: '销售数量',
			width: 120,
			align: "center"
		}, {
			field: 'goodsSkin',
			title: '浏览量',
			width: 80,
			align: "center"
		},
	
		{
			title: '操作',
			toolbar: '#tool',
			fixed: "right",
			width: 200,
			align: "center"
		}
	]
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 350,
		url: ip + url, //数据接口  
		page: false,
		headers: {
			token: getSession("token")
		},
		where: {
			classfyId: classfyId
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [colList]

	});
}
