var $, layer, upload, form, layedit;
var form;
var imgsId = 0;
var count = 0; //标签个数
var attr = [];
var goodsCover; //封面图
var goodsBanner = []; //商品轮播图
// var classfyId = getUrlParam("classfyId");
var Introduce = []; //商品介绍图
var Parameter = []; //商品租赁流程
var Tip = []; //租赁必读图
var allImgsUploadId = ['#uploadGoodsBanner'];
var allImgsShowId = ["#showGoodsBanner"];
layui.use(['layer', 'form', 'jquery', 'upload', 'layedit'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;


	var E = window.wangEditor
	/* 商品介绍 */
	Introduce = new E("#goodsIntroduce")
	Introduce.customConfig.menus = [
		'head', // 标题
		'bold', // 粗体
		'fontSize', // 字号
		'fontName', // 字体
		'italic', // 斜体
		'underline', // 下划线
		'strikeThrough', // 删除线
		'list', // 列表
		'justify', // 对齐方式s
		'image', // 插入图片
		'undo', // 撤销
	]
	// 隐藏“网络图片”tab
	Introduce.customConfig.showLinkImg = false
	/* 上传图片配置 */
	Introduce.customConfig.uploadImgServer = ip + 'util/multipartUploadImg';
	Introduce.customConfig.uploadImgParams = {
		path: `good/`
	}
	Introduce.customConfig.uploadFileName = 'files'
	Introduce.customConfig.uploadImgHeaders = {
		'token': getSession("token")
	}
	var load;
	Introduce.customConfig.uploadImgHooks = {
		before: function(xhr, editor, files) {
			load = layer.load(1, {
				offset: '50%',
				fixed: false,
				scrollbar: false
			})
		},
		// 如果服务器端返回的不是 {errno:0, data: [...]} 这种格式，可使用该配置
		// （但是，服务器端返回的必须是一个 JSON 格式字符串！！！否则会报错）
		customInsert: function(insertImg, result, editor) {
			layer.close(load)
			var data = result.data.urls;
			for (var i in data) insertImg(ip + data[i])

		}
	}
	Introduce.create()


	/* 规格参数 */
	Parameter = new E("#goodsParameter")

	Parameter.customConfig.menus = [
		'head', // 标题
		'bold', // 粗体
		'fontSize', // 字号
		'fontName', // 字体
		'italic', // 斜体
		'underline', // 下划线
		'strikeThrough', // 删除线
		'list', // 列表
		'justify', // 对齐方式s
		'image', // 插入图片
		'undo', // 撤销
	]
	// 隐藏“网络图片”tab
	Parameter.customConfig.showLinkImg = false
	/* 上传图片配置 */
	Parameter.customConfig.uploadImgServer = ip + 'util/multipartUploadImg';
	Parameter.customConfig.uploadImgParams = {
		path: `good/`
	}
	Parameter.customConfig.uploadFileName = 'files'
	Parameter.customConfig.uploadImgHeaders = {
		'token': getSession("token")
	}
	var load;
	Parameter.customConfig.uploadImgHooks = {
		before: function(xhr, editor, files) {
			load = layer.load(1, {
				offset: '50%',
				fixed: false,
				scrollbar: false
			})
		},
		// 如果服务器端返回的不是 {errno:0, data: [...]} 这种格式，可使用该配置
		// （但是，服务器端返回的必须是一个 JSON 格式字符串！！！否则会报错）
		customInsert: function(insertImg, result, editor) {
			layer.close(load)
			var data = result.data.urls;
			for (var i in data) insertImg(ip + data[i])
		}
	}
	Parameter.create()



	/* 租赁必读 */
	Tip = new E("#goodsTip")
	Tip.customConfig.menus = [
		'head', // 标题
		'bold', // 粗体
		'fontSize', // 字号
		'fontName', // 字体
		'italic', // 斜体
		'underline', // 下划线
		'strikeThrough', // 删除线
		'list', // 列表
		'justify', // 对齐方式s
		'image', // 插入图片
		'undo', // 撤销
	]
	// 隐藏“网络图片”tab
	Tip.customConfig.showLinkImg = false
	/* 上传图片配置 */
	Tip.customConfig.uploadImgServer = ip + 'util/multipartUploadImg';
	Tip.customConfig.uploadImgParams = {
		path: `good/`
	}
	Tip.customConfig.uploadFileName = 'files'
	Tip.customConfig.uploadImgHeaders = {
		'token': getSession("token")
	}
	var load;
	Tip.customConfig.uploadImgHooks = {
		before: function(xhr, editor, files) {
			load = layer.load(1, {
				offset: '50%',
				fixed: false,
				scrollbar: false
			})
		},
		// 如果服务器端返回的不是 {errno:0, data: [...]} 这种格式，可使用该配置
		// （但是，服务器端返回的必须是一个 JSON 格式字符串！！！否则会报错）
		customInsert: function(insertImg, result, editor) {
			layer.close(load)
			var data = result.data.urls;
			for (var i in data) insertImg(ip + data[i])
		}
	}

	Tip.create()





	watchFun();
	// dealAttr();
	// 轮播图
	uploadImgs(goodsBanner, 0);

	// 封面图
	uploadImg();

	//监听提交
	toSubmit();

});


/**
 * 监听事件
 */
function watchFun() {

}

/**
 * 提交表单
 */
function toSubmit() {

	form.on('submit(submit)', function(data) {
		var load;
		var param = data.field;
		if (goodsCover == "" || !goodsCover) {
			layer.msg('请上传封面图', {
				icon: 2,
				offset: '50%',
				fixed: false,
			});
			return;
		}
		if (goodsBanner == "" || !goodsBanner) {
			layer.msg('请上传轮播图', {
				icon: 2,
				offset: '50%',
				fixed: false,
			});
			return;
		}
		delete param.file;
		param.goodsCover = goodsCover;
		param.goodsBanner = goodsBanner.join(",");
		param.goodsIntroduce = removeWordXml(Introduce.txt.html())
		param.goodsParameter = removeWordXml(Parameter.txt.html())
		param.goodsTip = removeWordXml(Tip.txt.html())
		param.classfyId = 0;
		param.goodsStock = 9999;
		param.goodsMaxPrice = parseInt(param.goodsMaxPrice * 100);
		param.goodsMinPrice = parseInt(param.goodsMinPrice * 100);
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
			scrollbar: false
		});
		postJsonData("goods/insertGoods", param, res => {
			layer.close(load);
			if (res.code == 0) {
				// 添加属性
				layer.open({
					title: '提示',
					content: '商品的属性是必填的，请为此商品添加至少一项属性',
					offset: '50%',
					fixed: false,
					scrollbar: false,
					yes: function() {
						window.location.href = '../attr/addAttr.html?goodsId=' + res.data.goodsId;
					}
				});
			} else {
				layer.msg(res.msg || '添加失败', {
					icon: 2,
					offset: '50%',
					fixed: false,
				});
			}
		})
	});
}


/**
 * 跳转至标签页面
 */
function toAttr() {
	x_admin_show_all_ref('属性', '../attr/attr.html');
}




/**
 * 单张图片上传
 */
function uploadImg() {
	//普通图片上传
	var load1;
	var uploadInst = upload.render({
		elem: '#uploadImg',
		url: ip + 'util/multipartUploads',
		before: function(obj) {
			load1 = layer.load(0, {
				offset: '50%',
				fixed: false,
				scrollbar: false
			});
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				$('#fengmian').attr('src', result); //图片链接（base64）
			});


		},
		headers: {
			token: getSession("token")
		},
		data: {
			path: "good/"
		},
		done: function(res) {
			layer.close(load1);
			if (res.code == 401) {
				top.location = '../login.html';
			}
			//如果上传失败
			if (res.code == 0) {
				goodsCover = res.data.urls[0]
			}
			if (res.code > 0) {
				return layer.msg('上传失败');
			}
		},
		error: function() {
			//演示失败状态，并实现重传
			var demoText = $('#demoText');
			demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
			demoText.find('.demo-reload').on('click', function() {
				uploadInst.upload();
			});

		}
	});

}


/**
 * 多图片上传
 */
function uploadImgs(imgArr, num) {
	//多图片上传
	var load;
	upload.render({
		elem: allImgsUploadId[num],
		url: ip + 'util/multipartUploads',
		multiple: true,
		data: {
			path: "good/"
		},
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			imgsId++;
			load = layer.load(0, {
				offset: '50%',
				fixed: false,
				scrollbar: false
			});
			//预读本地文件示例，不支持ie8
			// 			obj.preview(function(index, file, result) {
			// 				var i=index.split("-")[1]
			// 				$('#showGoodsBanner').append('<img onclick="deleteImg(' + i +","+num+ ')" src="' + result + '" alt="' + file.name +
			// 					'" class="layui-upload-img">');
			// 			});
		},
		done: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.code == 0) {
				imgArr.push(res.data.urls[0])
			}
		},
		allDone: function(res) {
			layer.close(load);
			showImg(imgArr, num);
		},
	});
}

// 渲染图片到页面
function showImg(imgArr, num) {
	var all;
	for (var i = 0; i < imgArr.length; i++) {
		var temp = '<img  onclick="deleteImg(' + i + "," + num + ')" src="' + ip + imgArr[i] +
			'" class="layui-upload-img my-img" style="width:200px;margin-right:10px;"><a class="img-edit" data-src="' + imgArr[i] +
			'" data-index="' + i + '"> <i class="iconfont" style="font-size:20px;position: absolute;left:' + (i + 1) * 0.97 *
			210 + 'px;z-index:3">&#xe69e;</i> </a>';
		if (!all) {
			all = temp
		} else {
			all += temp;
		}
	}
	$(allImgsShowId[num]).empty();
	$(allImgsShowId[num]).append(all);

	/* 更换图片 */
	$('.img-edit').click(function() {
		curThis = $(this)
		console.log(curThis)
	})

	/* 更换图片 */
	uploadPic('.img-edit', false, res => {
		console.log(goodsBanner);
		let imgIndex = curThis.data('index');
		editDeleteImg(imgIndex, 0)
		allImgsShowId[imgIndex] = res[0]
		curThis.prev().attr('src', `${ip}${res[0]}`);
		goodsBanner.splice(imgIndex, 0, res[0]);
		console.log(goodsBanner);
	})
}

// 点击删除图片
function deleteImg(i, num) {
	var imgs;
	if (num == 0) {
		imgs = goodsBanner;
	}

	layer.confirm('确定删除此图片?', {
		icon: 3,
		title: '提示',
		offset: '50%',
		fixed: false,
		scrollbar: false,
		yes: function(index, layero) {
			//do something
			param = {};
			param.urls = imgs[i]
			getData("util/deleteFiles", param, res => {
				layer.close(index); //如果设定了yes回调，需进行手工关闭
				if (res.code == 0) {
					imgs.splice(i, 1);
					showImg(imgs, num);
					layer.msg('删除成功', {
						icon: 1,
					});
				} else {
					layer.msg(res.msg || '删除失败', {
						icon: 2
					});
				}
			})
		}
	});
}

function editDeleteImg(i, num) {
	var imgs;
	if (num == 0) {
		imgs = goodsBanner;
	}
	param = {};
	param.urls = imgs[i]
	imgs.splice(i, 1);

}
