var $, layer, form;
var goodsId = getUrlParam("goodsId")
var resData = JSON.parse(getSession("resData"));
clearSession("resData")
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;

	//监听提交
	toSubmit();

});


/**
 * 表单提交
 */
function toSubmit() {
	form.on('submit(submit)', function(data) {
		var load;
		load = layer.load();
		param = {};
		param.orderId = resData.orderId
		param.reorderId = resData.reorderId
		param.reorderNo = resData.reorderNo
		param.reorderExpcom = resData.reorderExpcom
		param.status = 2
		param.reorderPhoto = resData.reorderPhoto
		param.userId = resData.userId
		getData("reorder/updateReorderStatus", param, res => {
			layer.close(load);
			if (res.code == 0) {
				layer.msg('确认收货成功', {
					icon: 1,
					time: 1500
				});
			} else {
				layer.msg(res.msg, {
					icon: 2,
					time: 1500
				});
			}
		})

	});

}
