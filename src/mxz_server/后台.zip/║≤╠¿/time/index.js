var $, table, layer, laytpl;
var param = {};
var isFormIndex = false; //判断是否从首页的商品跳转的页面
if (getUrlParam("isFormIndex")) {
	isFormIndex = getUrlParam("isFormIndex")
}
layui.use(['layer', 'jquery', 'table', 'laytpl'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	laytpl = layui.laytpl;

	// 获取数据
	showTable()
	//监听行工具事件
	watchToolBar();
	//监听头部工具
	watchSelect();
	// 点击编辑
	toEdit()

});

/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
	

		if(obj.event ==='edit'){
			setSession("extra", JSON.stringify(resData))
			x_admin_show_all('修改工作时间', './edit.html');
		}		
	});
}

function watchSelect() {
	table.on('toolbar(list)', function(obj) {
		switch (obj.event) {
			case 'reload':
				toSearch(this)
				break;
				// 添加商品
			case 'toAdd':
				toAdd()
				break;
		};
	});
}


/**
 * 渲染表格
 */
function showTable() {
	var colList = [{
			field: 'extraId',
			title: 'Id',
			width: 80,
			fixed: 'left',
			align: "center",
			sort: true
		},
		{
			field: 'extraDesc',
			title: '标题',
			width: 250,
			align: "center",
			edit:true,
			sort: true
		},
		{
			field: 'extraTitle',
			title: '内容',
			align: "center",
			sort: true
		},	
		{
			title: '操作',
			toolbar: '#tooldel',
			fixed: "right",
			align: "center",
			width: 150
		}
	]
	//插入表格数据
	table.render({
		elem: '#list',
		toolbar: '#toolbarDemo',
		defaultToolbar: [],
		url: ip + 'extra/selectTimeLay', //数据接口  
		page: true,
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [colList]
	});
}

/**
 * 点击搜索
 */
function toEdit() {
	// 监听单元格的编辑
	table.on('edit(list)', function(param) {
		console.log(param)
		postFormData('extra/updateExtra', param.data, res => {
			if (res.code == 0) { // 成功
				layer.msg("修改成功");
				// 数据重载
				table.reload('all');
			} else { // 失败
				layer.msg("修改失败");
			}
		})
	});
}
