var $;
var form, layer;
var classfyA; //一级分类
var classfyB; //二级分类
var classfyData = JSON.parse(getSession("classfyData"))
clearSession("classfyData")
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;


	// 获取分类
	getClassfy(res => {
		// 渲染表单
		showForm();
	});


	// 监听select
	watchSelect();
	//监听提交
	form.on('submit(submit)', function(data) {
		var classfyId = data.field.classfyB;
		if (!classfyId) {
			layer.msg('您尚未选择分类', {
				icon: 2
			});
			return;
		}
		var mySelectClassfy = classfyData.iconSrc; //我选择的分类
		if (!mySelectClassfy) {
			mySelectClassfy = []
		} else {
			mySelectClassfy = classfyData.iconSrc.split("-");
			for (var i in mySelectClassfy) {
				if (parseInt(classfyId) === parseInt(mySelectClassfy[i])) {
					layer.msg('您已经选择该分类', {
						icon: 2
					});
					return;
				}
			}
		}
		mySelectClassfy.push(classfyId);
		mySelectClassfy = mySelectClassfy.join("-");
		classfyData.iconSrc = mySelectClassfy

		// 合拼分类
		var load;
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
		});
		postJsonData("icon/updateIcon", classfyData, res => {
			layer.close(load);
			if (res.code == 0) {
				layer.msg('增加成功', {
					icon: 1,
					time: 1500,
					offset: '50%',
					fixed: false,
				});
			} else {
				layer.msg('增加失败', {
					icon: 2,
					time: 1500
				});
			}
		})

	});
});


/**
 * 获取一级分类和第一个二级分类
 */
function getClassfy(Callback) {
	// 获取一级分类
	let param1 = {
		pid: 0,
	}
	selectClassfies(param1, res1 => {
		if (res1.data) {
			classfyA = res1.data;
			showForm();
		}
	})
}

/**
 * 监听select
 */
function watchSelect() {
	form.on('select(classfyA)', function(data) {
		var classfyId = data.value;
		// 获取classfyB
		let param = {
			pid: classfyId
		}
		var load;
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
		});
		selectClassfies(param, res2 => {
			layer.close(load);
			if (res2.data) {
				classfyB = res2.data;
				// 渲染
				showClassfyB();
			}
		})

	});
}

/**
 * 获取分类
 */
function selectClassfies(param, Callback) {
	getData("classfy/selectClassfies", param, res => {
		if (res.code != 0) {
			layer.msg('获取失败', {
				icon: 2
			});
			return;
		} else {
			Callback(res)
		}
	})
}

/**
 * 渲染表单
 */
function showForm() {
	showClassfyA();

}


/**
 * 渲染classfyA
 */
function showClassfyA() {
	for (var i in classfyA) {
		// $("#classfyA").empty();
		var temp;
		temp = '<option value="' + classfyA[i].classfyId + '">' + classfyA[i].classfyTitle + '</option>';
		$("#classfyA").append(temp);
	}
	form.render(); //更新全部
}
/**
 * 渲染classfyB
 */
function showClassfyB() {
	$("#classfyB").empty();
	var temp;
	temp = '<option value="">请选择二级分类</option>';
	$("#classfyB").append(temp);
	for (var i in classfyB) {
		temp = '<option value="' + classfyB[i].classfyId + '">' + classfyB[i].classfyTitle + '</option>';
		$("#classfyB").append(temp);
	}
	form.render(); //更新全部
}
