var $, table, layer, form;
var param = {};
var classfyData; //当前分类数据
layui.use(['layer', 'form', 'jquery', 'upload', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;
	table = layui.table;


	// 渲染表格
	showTable();



	//监听行工具事件
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		let param = obj.data;
		setSession("editParam", JSON.stringify(param))
		// 添加分类
		if (obj.event === 'toAdd') {
			x_admin_show_all('添加分类', './addTitle.html');
		}
		// 编辑分类
		if (obj.event === 'edit') {
			x_admin_show_all('编辑分类', './editTitle.html');
		}
		// 删除分类
		if (obj.event === 'del') {
			param = {};
			param.classfyId = obj.data.classfyId
			deleteTableFun(obj, "classfy/deleteClassfy", param, "确定删除此分类？")
		}
		// 跳转到商品
		if (obj.event === 'toGoods') {
			x_admin_show_all('商品', '../goods/goods.html?classfyId=' + param.classfyId);
		}
	});


});


/**
 * 添加分类
 */
function toAdd() {
	x_admin_show_all('添加分类', './addTitle.html');
}
/**
 * 渲染表格
 */
function showTable() {
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 350,
		url: ip + 'classfy/selectClassfies', //数据接口  
		where: {
			pid: -1
		},
		page: false,
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [
			[ //表头
				{
					field: 'classfyTitle',
					title: '导航名称',
					width: 250,
					align: "center"
				},
				{
					title: '导航商品',
					toolbar: '#good',
					align: "center"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 250,
					align: "center"
				}
			]
		]

	});
}


/**
 * 删除数据
 */
function deleteData(classfyId, Callback) {
	var mySelectClassfy = classfyData.iconSrc; //我选择的分类
	if (!mySelectClassfy) {
		mySelectClassfy = []
	} else {
		mySelectClassfy = classfyData.iconSrc.split("-");
		var index = mySelectClassfy.indexOf(classfyId + "");
		if (index > -1) {
			mySelectClassfy.splice(index, 1);
		}
		mySelectClassfy = mySelectClassfy.join("-");
		classfyData.iconSrc = mySelectClassfy;
		postJsonData("icon/updateIcon", classfyData, res => {
			Callback(res)
		})
	}
}
