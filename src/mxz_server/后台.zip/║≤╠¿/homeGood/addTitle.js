var $;
var form;
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;
	form = layui.form;

	//监听提交
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.pid = -1;
		postFormData('classfy/insertClassfy', param, res => {
			if (res.code == 0) {
				var index = layer.open({
					content: '添加成功',
					btn: ['继续添加', '取消'],
					yes: function(index, layero) {
						// 清空表单
						$("#form1")[0].reset();
						layui.form.render()
						layer.close(index)
					},
					btn2: function(index, layero) {
						parent.location.reload();
						x_admin_close();
					},
					cancel: function(index, layero) {
						parent.location.reload();
						x_admin_close();
					}
				});
			} else {
				layer.msg('增加失败', {
					icon: 2
				});
			}
		})
	});
});
