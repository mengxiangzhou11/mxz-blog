﻿var $, layer, form, table;
var bannerData = [];
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;
	table = layui.table;


	showTable();
	watchEdit();

});




/**
 * 渲染表格
 */
function showTable(data) {
	//插入表格数据
	table.render({
		elem: '#stepwiseTable',
		// height: 350,
		url: ip + 'icon/selectCommonIcons', //数据接口         
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			var data = res.data.slice(11,15);
			return {
				"code": res.code, //解析接口状态
				"data": data //解析数据列表
			}

		},
		page: false, //开启分页
		cols: [
			[ //表头
				{
					field: 'iconTitle',
					title: '所属位置',
					width: 400,
					align: "center"
				}, {
					field: 'iconSrc',
					title: '内容(点击可修改 建议:内容不超4字)',
					align: "center",
					style: "color:red",
					edit: "text"
				}
			]
		]

	});


}




/**
 * 监听行内编辑
 */
function watchEdit() {
	table.on('edit(stepwiseTable)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		let param = obj.data
		var index = $("tr").index(obj.tr) - 1;
		param[obj.field] = obj.value;
		updateFun(param)

	});
}

/**
 * 更新数据的方法
 */
function updateFun(param) {
	var load1;
	load1 = layer.load(0, {
		offset: '50%',
		fixed: false,
	});
	postJsonData("icon/updateIcon", param, res => {
		layer.close(load1);
		if (res.code != 0) {
			layer.open({
				title: '提示',
				content: '更新失败',
				offset: '50%',
				fixed: false,
				yes: function() {
					location.reload();
				}
			});
		}
	})
}
