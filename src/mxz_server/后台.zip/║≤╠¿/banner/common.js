// var ip = "https://zulin.tuqw.cn/";
var ip = "http://192.168.0.108:82/";
/**
 * 获取缓存
 */
function getSession(key) {
	let storate_data = localStorage.getItem(key);
	return storate_data;
}

/** 
 * 刷新当前页面
 */
const refreshPage = () => {
	window.location.reload()
}

/**
 * 设置缓存
 */
function setSession(key, value) {
	localStorage.setItem(key, value);
}

/**
 * 清除缓存
 */
function clearSession(key) {
	window.localStorage.removeItem(key);
}

/**
 * 获取地址栏参数的函数
 * 获取跳转地址的参数
 */
function getUrlParam(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}



/*获取主机地址*/
function getLocalPath() {
	var curWwwPath = window.document.location.href;
	var pathName = window.document.location.pathname;
	var pos = curWwwPath.indexOf(pathName);
	var localhostPath = curWwwPath.substring(0, pos);
	return localhostPath;
}

/*页面跳转*/
function toDetail(url, id) {
	var url = url + '?id=' + id;
	window.location.href = url;
}

/**
 * 跳转页面
 */
function toOtherPage(url) {
	window.location.href = url;
}



/**
 *跳转页面
 * 传入id
 */
function toEdit(url, id) {
	var url = url + '?id=' + id;
	window.location.href = url;
}

/**
 * 删除表格行方法
 * obj当前行的信息
 * url删除数据的接口
 * param删除数据的参数
 * title提示语句
 */
const deleteTableFun = (obj, url, param, title) => {
	var de = layer.confirm(title, {
		icon: 3,
		title: '提示',
		offset: '50%',
		fixed: false,
		scrollbar: false,
		yes: function(index, layero) {
			layer.close(de)
			var load;
			load = layer.load();
			getData(url, param, res => {
				layer.close(load);
				if (res.code == 0) {
					obj.del();
					layer.msg('删除成功', {
						icon: 1,
						title: '提示',
						offset: '50%',
						fixed: false,
						scrollbar: false,
						time: 1500
					});
				} else {
					layer.msg('删除失败', {
						icon: 2,
						title: '提示',
						offset: '50%',
						fixed: false,
						scrollbar: false,
						time: 1500
					});
				}
			})
		}
	});

}

function getData(url, param, callback) {
	$.ajax({
		url: ip + url,
		data: param,
		cache: false,
		headers: {
			"token": getSession("token")
		},
		complete: function(response, status, xhr) {
			var data = response.responseJSON;
			if (data.code == 401) {
				// window.location.href = '../login.html'
				top.location = '../login.html';
			}
			callback(data)
		},
	})
}

function postData(url, param, callback) {
	$.ajax({
		url: ip + url,
		data: param,
		method: 'post',
		cache: false,
		headers: {
			"Content-Type": "application/json",
			"token": getSession("token")
		},
		complete: function(response, status, xhr) {
			var data = response.responseJSON;
			if (data.code == 401) {
				// window.location.href = '../login.html'
				top.location = '../login.html';
			}
			callback(data)
		},
		dataType: "json"
	})
}

function postJsonData(url, param, callback) {
	$.ajax({
		url: ip + url,
		data: JSON.stringify(param),
		method: 'post',
		cache: false,
		headers: {
			"Content-Type": "application/json",
			"token": getSession("token")
		},
		complete: function(response, status, xhr) {
			var data = response.responseJSON;
			if (data.code == 401) {
				// window.location.href = '../login.html'
				top.location = '../login.html';
			}
			callback(data)
		},
		dataType: "json"
	})
}

const postFormData = (url, data, callback) => {
	$.ajax({
		url: ip + url,
		data: data,
		method: "POST",
		headers: {
			"Content-Type": "application/x-www-form-urlencoded",
			"token": getSession("token")
		},
		complete: function(response, status, xhr) {
			var data = response.responseJSON;
			if (data.code == 401) {
				// window.location.href = '../login.html'
				top.location = '../login.html';
			}
			callback(data)
		},
	})
}



/*时间转换*/
function fmtDate(obj) {
	var date = new Date(obj);
	var y = 1900 + date.getYear();
	var m = "0" + (date.getMonth() + 1);
	var d = "0" + date.getDate();
	return y + "-" + m.substring(m.length - 2, m.length) + "-" + d.substring(d.length - 2, d.length);
}


/**
 * @param {Object} str
 */
function formatDate(num) {
	num = parseInt(num)
	let date = new Date(num),
		M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1),
		Y = date.getFullYear(),
		D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate(),
		h = date.getHours() < 10 ? '0' + date.getHours() : date.getHours(),
		m = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes(),
		s = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
	return `${Y}-${M}-${D} ${h}:${m}:${s}`;
}

function stampToTime(timestamp) {
  if (timestamp == 0) {
    return "";
  } else {
    var date = new Date(timestamp * 1);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
    var Y = date.getFullYear();
    var M = date.getMonth() + 1;
    var D = date.getDate();
    var h = date.getHours();
    var m = date.getMinutes();
    var s = date.getSeconds();
    var datestring = Y + "-";
    if (M < 10) datestring += "0";
    datestring += M + "-";
    if (D < 10) datestring += "0";
    datestring += D + " ";
    if (h < 10) datestring += "0";
    datestring += h + ":";
    if (m < 10) datestring += "0";
    datestring += m + ":";
    if (s < 10) datestring += "0";
    datestring += s;
    return datestring;
  }
}

/**
 *处理以逗号分割字符串，转化为数组
 *传入一个以逗号分隔的字符串
 *返回一个数组
 */
function dealStr(str) {
	var array = [];
	if (!str || str == "undefined" || str == "null" || str == "") {
		return array;
	}
	// 把获取的数据转化为字符串类型
	str = str.toString()
	// 如果字符串的首位和末位时逗号的，先把逗号去掉
	if (str[0] == ",") {
		str = str.slice(1, str.length);
	}
	if (str[str.length - 1] == ",") {
		str = str.slice(0, str.length - 1);
	}
	array = str.split(",");
	return array;
}

function dealStr1(str) {
	var array = [];
	if (!str || str == "undefined" || str == "null" || str == "") {
		return array;
	}
	// 把获取的数据转化为字符串类型
	str = str.toString()
	// 如果字符串的首位和末位时逗号的，先把逗号去掉
	if (str[0] == "-") {
		str = str.slice(1, str.length);
	}
	if (str[str.length - 1] == "-") {
		str = str.slice(0, str.length - 1);
	}
	array = str.split("-");
	return array;
}



/*
  弹出层展开至最大化
  点击关闭，并刷新页面
    参数解释：
    title   标题
    url     请求的url
    id      需要操作的数据id
    w       弹出层宽度（缺省调默认值）
    h       弹出层高度（缺省调默认值）
*/
function x_admin_show_all(title, url, w, h) {
	if (title == null || title == '') {
		title = false;
	};
	if (url == null || url == '') {
		url = "404.html";
	};
	if (w == null || w == '') {
		w = $(window).width();
	};
	if (h == null || h == '') {
		h = $(window).height();
	};
	layer.open({
		type: 2,
		area: ['100%', '100%'],
		fix: true, //不固定
		maxmin: true,
		shadeClose: true,
		shade: 0.4,
		offset: ['0px', '0px'],
		title: title,
		content: url,
		maxmin: true,
		scrollbar: true,
	});
}

/**
 * 弹出层展开至最大化
 * 点击关闭，并刷新页面
 */
function x_admin_show_all_ref(title, url, w, h) {
	if (title == null || title == '') {
		title = false;
	};
	if (url == null || url == '') {
		url = "404.html";
	};
	if (w == null || w == '') {
		w = $(window).width();
	};
	if (h == null || h == '') {
		h = $(window).height();
	};
	layer.open({
		type: 2,
		area: ['100%', '100%'],
		fix: true, //不固定
		maxmin: true,
		shadeClose: true,
		shade: 0.4,
		offset: ['0px', '0px'],
		title: title,
		content: url,
		maxmin: true,
		scrollbar: true,
		cancel: function(index, layero) {
			location.reload();
		}
	});
}



/**
 *删除/增加数组的元素
 * @param
 * type  0--删除，1--添加
 * value  删除或者要添加的元素
 * array  当前数组
 * return code==0   ok
 * return code==1   元素不存在此数组
 * return code==0   ok
 */
function dealArray(value, array) {
	var data = {};
	// 删除
	if (type == 0) {
		var index = array.indexOf(value);
		if (index > -1) {
			array.splice(index, 1);
			data.msg = "删除成功"
			data.code = 0;
			data.array = array
			return data;
		}
		// 元素不存在此数组
		else {
			data.code = 1;
			data.msg = "元素不存在此数组"
			return data;
		}
	} else if (type == 1) {
		if (!array) {
			array = []
		}
		if (array.indexOf(value) > -1) {
			data.code = 2;
			data.msg = "元素已存在此数组"
			return data;
		} else {
			array.push(value);
			data.code = 0;
			data.msg = "添加成功";
			data.array = array
			return data;
		}
	}
}

function uploadPic(id, multiple, Callback) {
	let load;
	upload.render({
		elem: `${id}`,
		url: ip + 'util/singleUpload',
		multiple: multiple,
		data: {
			path: "good/"
		},
		headers: {
			"token": getSession("token")
		},
		before: function(obj) {
			load = layer.load(1, {
				fixed: false,
				scrollbar: false
			});
		},
		done: function(res) {
			layer.close(load);
			//如果上传失败
			if (res.code != 0) {
				layer.msg('上传失败');
			}
			if (res.code == 401) {
				top.location = '../login.html';
			}

			//上传成功
			let url = res.data;
			if (typeof url == 'string') url = [url]
			Callback(url)
		},
		error: function() {
			layer.close(load);
		}
	});
}
