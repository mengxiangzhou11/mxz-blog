var $;
var param = {};
var imgs = [];
var iconData;
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;



	// 获取轮播
	getData("icon/selectCommonIcons", {}, res => {
		if (res.code == 0) {
			iconData = res.data
			var iconSrc = res.data[4].iconSrc;
			if (iconSrc) {
				imgs = iconSrc.split('-')
			}
			showImg()
		}
	})



	//多图片上传
	var load;
	upload.render({
		elem: '#uploadsImg',
		url: ip + 'util/multipartUploads',
		multiple: true,
		data: {
			path: "banner/"
		},
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			load = layer.load();
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				// 				$('#showImgs').append('<img onclick="deleteImg(' + index + ')" src="' + result + '" alt="' + file.name +
				// 					'" class="layui-upload-img my-img">')
			});
		},
		done: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.code == 0) {
				imgs.push(res.data.urls[0])
			}
		},
		allDone: function(res) {
			layer.close(load);
			showImg()

		},
	});
});

// 渲染图片到页面
function showImg() {
	var all;
	for (var i = 0; i < imgs.length; i++) {
		var temp = '<img onclick="deleteImg(' + i + ')" src="' + ip + imgs[i] + '" class="layui-upload-img my-img">';
		if (!all) {
			all = temp
		} else {
			all += temp;

		}
	}

	$("#showImgs").empty();
	$('#showImgs').append(all)


}

// 点击删除图片
function deleteImg(i) {
	layer.confirm('确定删除此图片?', {
		icon: 3,
		title: '提示',
		offset: '50%',
		fixed: false,
		scrollbar:false,
		yes: function(index, layero) {
			//do something
			imgs.splice(i, 1);
			showImg();
			layer.msg('删除成功', {
				icon: 1,
				time: 1500
			});
		}
	});
}

// 点击提交
function toSubmit() {
	if (imgs.length < 1 || imgs.length > 5) {
		layer.msg('最少一张图片，最大5张图片', {
			icon: 2,
			time: 1500
		});
		return;
	}
	var load;
	load = layer.load(0, {
		offset: '50%',
		fixed: false,
	});
	iconData[4].iconSrc = imgs.join("-");
	postJsonData("icon/updateIcon", iconData[4], res => {
		layer.close(load);
		if (res.code == 0) {
			layer.msg('修改成功', {
				icon: 1,
				time: 1500,
				offset: '50%',
				fixed: false,
			});
		} else {
			layer.msg('修改失败', {
				icon: 2,
				time: 1500
			});
		}
	})


}
