var $, layer, form, table, upload;
var bannerData = [];
var bannerArr = [];
var param = {};
var slidIndex;
var bannerStr = "";
var goodsId = getUrlParam("goodsId")
layui.use(['layer', 'form', 'jquery', 'table', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;
	table = layui.table;
	upload = layui.upload;

	// 获取轮播
	getData("icon/getSlid", {}, res => {
		if (res.code == 0) {
			for (var i in res.data.slide) {
				// let temp = res.data.linkArr[i]
				let temp = {};
				temp.imgSrc = res.data.slide[i]
				bannerData[i] = temp;
				bannerStr += res.data.slide[i] + ",";
			}
			bannerStr = (bannerStr.substring(bannerStr.length - 1) == ',') ? bannerStr.substring(0, bannerStr.length - 1) :bannerStr;
			bannerArr = bannerStr.split(",");
			showTable(bannerData);
		}
	})

	watchEdit();
	watchToolBar()
	uploadImg('#upload1')

});


/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(bannerTable)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		slidIndex = index;
		var resData = obj.data;
		if (obj.event === 'edit') {
			param = {};
			param.slidIndex = index
		} else if (obj.event === 'remove') {
			param = {};
			param.slidIndex = index;
			layer.confirm("真的要删除图片么？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					bannerArr.splice(slidIndex, 1)
					getData("icon/updateIconBanner", {
						'banner': bannerArr.join("-")
					}, res => {
						layer.close(load);
						location.reload()
					})
				}
			});
		}
	});

}




/**
 * 渲染表格
 */
function showTable(data) {
	table.render({
		elem: '#bannerTable',
		url: '', //数据接口
		data: data,
		size: 'lg',
		page: false, //开启分页
		done() {
			uploadImgFun()
		},
		cols: [
			[{
				field: 'LAY_TABLE_INDEX',
				title: '序号',
				width: 150,
				align: "center",
				templet: '#index'
			}, {
				field: 'imgSrc',
				title: '轮播图',
				align: "center",
				templet: '#imgSrc',
				event: "changBanner"
			}, {
				title: '操作',
				toolbar: '#barDemo',
				align: 'center'
			}]
		]
	});


}




/**
 * 监听行内编辑
 */
function watchEdit() {
	table.on('edit(bannerTable)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		let field = obj.field;
		var index = $("tr").index(obj.tr) - 1;
		let param = {
			slidIndex: index,
		}
		if (field == "page") {
			param.pages = obj.value;
			updateFun("icon/updateSlidPages", param)
		}

	});
}

function uploadImg(elem) {
	upload.render({
		elem: elem,
		url: ip + 'util/multipartUploads',
		before: function(obj) {
			load = layer.load();
		},
		headers: {
			token: getSession("token")
		},
		data: {
			path: "banner/"
		},
		done: function(res) {

			//如果上传失败
			if (res.code !=0) {
				return layer.msg('上传失败', {
					icon: 5,
					time: 1000 // 1秒关闭（如果不配置，默认是3秒）
				}, function() {
					layer.close(load)
				});
				//上传成功
			} else {
				bannerStr+=","+res.data.urls[0];
				bannerArr = bannerStr.split(",");
				getData("icon/updateIconBanner", {'banner':bannerArr.join("-")}, res => {
					if (res.code == 0) {
						layer.msg("添加成功", {
							icon: 1,
							time: 1000 // 1秒关闭（如果不配置，默认是3秒）
						}, function() {
							layer.close(load);
							// table.reload('bannerTable')
							location.reload()
						});
					} else {
						layer.msg('添加失败', {
							icon: 5,
							time: 1500 // 1秒关闭（如果不配置，默认是3秒）
						}, function() {
							layer.close(load)
						});
					}
				})
			}

		},
		error: function() {
			//演示失败状态
			layer.msg('上传失败', {
				icon: 5,
				time: 1500 // 1秒关闭（如果不配置，默认是3秒）
			}, function() {
				//do something
				layer.close(load)
			});
		}
	});
}




/**
 * 单张图片上传
 */
function uploadImgFun() {
	//普通图片上传
	var load1;
	var uploadInst = upload.render({
		elem: '.test1',
		url: ip + 'util/multipartUploads',
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			load1 = layer.load(0, {
				offset: '50%',
				fixed: false,
			});
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				$('#img' + slidIndex).attr('src', result); //图片链接（base64）
			});
		},
		data: {
			path: "banner/"
		},
		done: function(res) {
			layer.close(load1);
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.code == 0) {
				// 修改轮播图
				let url = res.data.urls[0];
				param.src = url;
				updateFun("icon/udpateSlid", param)
			}
		},
	});

}

/**
 * 更新数据的方法
 */
function updateFun(url, param) {
	var load1;
	load1 = layer.load(0, {
		offset: '50%',
		fixed: false,
	});
	postFormData(url, param, res => {
		layer.close(load1);
		if (res.code != 0) {
			layer.open({
				title: '提示',
				content: '更新失败',
				offset: '50%',
				fixed: false,
				yes: function() {
					location.reload();
				}
			});
		}
	})
}
