var $, layer, upload, form;
var form;
var goodsId = getUrlParam("goodsId");
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	upload = layui.upload;
	form = layui.form;


	// 获取数据
	param = {};
	param.goodsId = goodsId
	var load;
	load = layer.load(0, {
		offset: '50%',
		fixed: false,
		scrollbar: false,
	});
	getData("goods/selectGoodsById", param, res => {
		layer.close(load);
		if (res.code == 0) {
			formData = res.data;
			// 表单渲染
			showForm();

			// 轮播图
			uploadImgs(goodsBanner, 0);

			// 商品介绍图
			uploadImgs(goodsIntroduce, 1)

			// 商品规格参数图
			uploadImgs(goodsParameter, 2)

			// 租赁必读图
			uploadImgs(goodsTip, 3)

			// 封面图
			uploadImg();

			//监听提交
			toSubmit()

		}

	})



});





/**
 * 提交表单
 */
function toSubmit() {
	form.on('submit(submit)', function(data) {
		var load;
		if (goodsCover == "" || !goodsCover) {
			layer.msg('请上传封面图', {
				icon: 2,
				offset: '50%',
				fixed: false,
			});
			return;
		}


		var param = Object.assign(formData, data.field);;
		delete param.file;
		delete param.attrs;
		param.goodsCover = goodsCover;
		param.goodsBanner = goodsBanner.join(",");
		param.goodsIntroduce = goodsIntroduce.join(",");
		param.goodsParameter = goodsParameter.join(",");
		param.goodsTip = goodsTip.join(",");
		param.goodsStock = 9999;
		// param.goodsDeposit = parseInt(param.goodsDeposit * 100);
		param.goodsMaxPrice = parseInt(param.goodsMaxPrice * 100);
		param.goodsMinPrice = parseInt(param.goodsMinPrice * 100);
		// param.goodsOffset = parseInt(param.goodsOffset * 100);
		// param.goodsPackPrice = parseInt(param.goodsPackPrice * 100);
		load = layer.load(0, {
			offset: '50%',
			fixed: false,
			scrollbar: false
		});
		postJsonData("goods/updateGoods", param, res => {
			layer.close(load);
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '50%',
					fixed: false,
					time: 1500,
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '50%',
					fixed: false,
				});
			}
		})
	});


}


/**
 * 表单渲染
 */
function showForm() {
	form.val("goodForm", {
		"goodsClassfyTitle": formData.goodsClassfyTitle,
	})

	// 渲染图片
	if (formData.goodsCover) {
		goodsCover = formData.goodsCover;
		$('#fengmian').attr('src', ip + goodsCover);
	}



}



/**
 * 单张图片上传
 */
function uploadImg() {
	//普通图片上传
	var load1;
	var uploadInst = upload.render({
		elem: '#uploadImg',
		url: ip + 'util/multipartUploads',
		headers: {
			token: getSession("token")
		},
		before: function(obj) {
			load1 = layer.load(0, {
				offset: '50%',
				fixed: false,
			});
			//预读本地文件示例，不支持ie8
			obj.preview(function(index, file, result) {
				$('#fengmian').attr('src', result); //图片链接（base64）
			});
		},
		data: {
			path: "good/"
		},
		done: function(res) {
			layer.close(load1);
			if (res.code == 401) {
				top.location = '../login.html';
			}
			//如果上传失败
			if (res.code == 0) {
				goodsCover = res.data.urls[0]
			}
			if (res.code > 0) {
				return layer.msg('上传失败');
			}
			//上传成功
		},
		error: function() {
			//演示失败状态，并实现重传
			var demoText = $('#demoText');
			demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
			demoText.find('.demo-reload').on('click', function() {
				uploadInst.upload();
			});
		}
	});

}


// 渲染图片到页面
function showImg(imgArr, num) {
	var all;
	for (var i = 0; i < imgArr.length; i++) {
		var temp = '<img onclick="deleteImg1(' + i + "," + num + ')" src="' + ip + imgArr[i] +
			'" class="layui-upload-img my-img" style="width:200px;margin-right:10px;">';
		if (!all) {
			all = temp
		} else {
			all += temp;
		}
	}
	$(allImgsShowId[num]).empty();
	$(allImgsShowId[num]).append(all);
}
