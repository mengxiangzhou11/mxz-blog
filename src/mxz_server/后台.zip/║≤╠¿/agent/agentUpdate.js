var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;
	
	init();
	
	//初始化表单数据
	function init() {
		var applyId =getSession("applyId");
		// let applyId = getUrlParam("applyId");
		if (applyId != null) {
			getData('applyAgent/searchById', {
				"applyId": applyId
			}, res => {
				if (res.code == 0) {
					userLogo = res.data.userLogo; //用户头像
					credentials = res.data.credentials; //相关证明
					form.val('withdrawfilter', {
						'applyId': res.data.applyId,
						'userId': res.data.userId,
						'realName': res.data.realName,
						'tel': res.data.tel,
						'alipayNickname': res.data.alipayNickname,
						'alipayAccount': res.data.alipayAccount,
						'explanation': res.data.explanation,
						// 'credentials': res.data.credentials,
					})
					// $('#pic').attr('src', ip + credentials);		
				}
			})
		}
	}

	//监听审核成功
	form.on('submit(pass)', function(data) {
		var param = data.field;
		getData("applyAgent/updateApplyAgent", {
			"applyId":param.applyId,"status":1
		}, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time: 1500
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
		return false;
	});

	//监听审核失败
	form.on('submit(fail)', function(data) {
		var param = data.field;
		getData("applyAgent/updateApplyAgent", {
			"applyId":param.applyId,"status":2
		}, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time: 1500
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
		return false;
	});
	
	//监听返回
	form.on('submit(reback)',function(data) {
	  var param=data.field;
	  parent.location.reload(); 
	  x_admin_close();
	   return false;
	});	
	//图片放大
	$("#pic").click(function(){
		var picUrl=$("#pic").attr("src");
			layer.photos({
		        photos:{"data":[{"src":picUrl}]}
		    }) 
	})
	
});