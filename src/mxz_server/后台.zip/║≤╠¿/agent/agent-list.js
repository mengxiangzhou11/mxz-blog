var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;
	//插入表格数据
	table.render({
		elem: '#agent',
		url: ip + 'applyAgent/searchAll', //数据接口
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location='../login.html';
			}
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
		},
		size: 'lg',
		page: true, //开启分页
		id: 'all',
		cols: [
			[ //表头
				{
					field: 'applyId',
					title: '编号',
					width: 80,
					align: "center",
				}, {
					field: 'userId',
					title: '用户id',
					align: "center",
					width: 80
				}, {
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 200
				}, {
					field: 'tel',
					title: '联系电话',
					align: "center",
					width: 200,
				}, {
					field: 'status',
					title: '状态',
					align: "center",
					templet: function(d) {
						if (d.status == 0) {
							return "待审核"
						} else if (d.status == 1) {
							return "审核通过"
						} else if (d.status == 2) {
							return "审核失败"
						}
					}
				}, {
					title: '操作',
					align: 'center',
					toolbar: '#barDemo',
					fixed: 'right',
				} //这里的toolbar值是模板元素的选择器
			]
		]
	});
		
	table.on('tool(testFliter)', function(obj) { //注：tool是工具条事件名，test是table原始容器的属性 lay-filter="对应的值"
		var data = obj.data; //获得当前行数据
		var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
		var tr = obj.tr; //获得当前行 tr 的DOM对象
	
		if (layEvent === 'search') { //查看
			setSession("applyId",data.applyId)
			x_admin_show_all('查看详细', './detail.html');
		}else if(layEvent==="edit"){		
			setSession("applyId",data.applyId)
			x_admin_show_all('审阅信息', './agentUpdate.html');
		}
	})	
	
	$("#notDoing").click(function() {
		var stutus = $("#notDoing").val()
		table.reload('all', {
			url: ip + 'applyAgent/searchAll', //数据接口
			where: {
				status: stutus
			}
		});
		layer.msg("数据已更新");
	});
	
});

