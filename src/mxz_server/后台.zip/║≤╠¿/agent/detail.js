var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;


	//初始化表单数据
	init();
		


function init() {
	var applyId =getSession("applyId");
	// let applyId = getUrlParam("applyId");
		if (applyId != null) {	
			getData('applyAgent/searchById', {
				"applyId": applyId
			}, res => {
				if (res.code == 0) {
					credentials = res.data.credentials; //相关证明
					form.val('testfilter',{
						'applyId': res.data.applyId,
						'userId': res.data.userId,
						'realName': res.data.realName,
						'tel': res.data.tel,
						'alipayNickname': res.data.alipayNickname,
						'alipayAccount': res.data.alipayAccount,
						'explanation': res.data.explanation,
						// 'credentials': res.data.credentials,
					})
					// $('#pic').attr('src', ip + credentials);		
				}
			})
		}
	}

	form.on('submit(reback)', function(data) {
		parent.location.reload(); 
		x_admin_close();
	})
	
	$("#pic").click(function(){
		var picUrl=$("#pic").attr("src");
			layer.photos({
		        photos:{"data":[{"src":picUrl}]}
		    }) 
	})
	
});