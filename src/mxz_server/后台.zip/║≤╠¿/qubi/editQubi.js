var $, layer, form;
var qubi;
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;


	// 获取数据
	getTheData().then(res=>{
		qubi=res.data;
		// 渲染表格
		showForm();
	});


	//监听提交
	toSubmit();

});

/**
 * 获取数据
 */
function getTheData() {
	return new Promise((resolve, reject) => {
		getData("icon/selectQuBiPercent", {}, res => {
			resolve(res)
		})
	})

}

/**
 * 渲染表单
 */
function showForm() {
	form.val("titleForm", {
		"percent": qubi, // "name": "value"
	})

}

function toSubmit() {
	form.on('submit(submit)', function(data) {
		var param = data.field;
		postFormData("icon/setQuBiPercent", param, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			} else {
				layer.msg('修改失败', {
					icon: 2,
					offset: '[50%,50%]',
					fixed: true,
					time: 1500
				});
			}
		})
	});

}
