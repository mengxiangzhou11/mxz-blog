var admin = getSession("admin");
admin = JSON.parse(admin);
var userId;
var isFormIndex;
/* 点击经销商->经销商商品进入的 */
if (getUrlParam('userId')) {
	userId = getUrlParam('userId');
	isFormIndex = false;
}

var $, table, layer, laytpl;
layui.use(['layer', 'jquery', 'table', 'laytpl'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	laytpl = layui.laytpl;

	// 获取数据
	showTable()


	//监听行工具事件
	watchToolBar();

	// 点击搜索
	toSearch();
	watchSelect()
});

/**
 * 监听选中行
 * 监听表格头部
 */
function watchSelect() {
	table.on('toolbar(list)', function(obj) {
		var checkStatus = table.checkStatus(obj.config.id);
		var goods = checkStatus.data
		switch (obj.event) {
			case 'toAdd':
				toAdd()
				break;
		};
	});
}

/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;


		// 取消授权到经销商
		if (obj.event === 'del') {
			let param = {
				goodIds: resData.goodsId,
				userId
			}
			deleteTableFun(obj, "userGood/delUserGood", param, "确定取消授权当前商品？")
		}
		// 授权经销商
		if (obj.event === 'toRole') {
			x_admin_show('授权经销商', '../all-dealer/index.html?goodsId=' + resData.goodsId);
		}

	});
}


/**
 * 跳转到添加商品
 */
function toAdd() {
	x_admin_show("添加商品到经销商", '../allGoods/allGoods.html?isFormIndex=dealer&userId=' + userId)
}
/**
 * 渲染表格
 */
function showTable() {
	var colList = [ //表头
		{
			field: 'goodsId',
			title: 'Id',
			width: 100,
			fixed: 'left',
			align: "center",
			sort: true
		},
		{
			field: 'goodsTitle',
			title: '商品名称',
			width: 250,
			align: "center",
			sort: true
		}, {
			field: 'goodsDesc',
			title: '商品描述',
			align: "center",
			width: 300,
			sort: true
		}, {
			title: '商品属性',
			align: "left",
			toolbar: '#attr',
			width: 300,
			sort: true
		}, {
			field: 'transport',
			title: '快递方式',
			width: 180,
			align: "center",
			templet: function(d) {
				return d.transport == 0 ? "包邮" : "到付"
			}
		}, {
			field: 'goodsCover',
			title: '商品封面图',
			width: 120,
			align: "center",
			templet: '#img1'
		}, {
			field: 'goodsBanner',
			title: '商品轮播图',
			width: 250,
			align: "center",
			templet: '#img2'
		}, {
			field: 'goodsIntroduce',
			title: '商品介绍图',
			width: 250,
			align: "center",
			// templet: '#img3'
		}, {
			field: 'goodsParameter',
			title: '租赁流程图',
			width: 250,
			align: "center",
			// templet: '#img4'
		}, {
			field: 'goodsTip',
			title: '租赁必读图',
			width: 250,
			align: "center",
			// templet: '#img5'
		}, {
			field: 'goodsPackPrice',
			title: '本店活动',
			width: 180,
			align: "center",
			sort: true
		}, {
			field: 'goodsSaleNum',
			title: '销售数量',
			width: 120,
					sort:true,
			align: "center",
			sort: true
		}, {
			field: 'goodsSkin',
			title: '浏览量',
			width: 120,
					sort:true,
			align: "center",
			sort: true
		}, {
			field: 'goodsStock',
			title: '库存',
			width: 80,
					sort:true,
			align: "center",
			sort: true
		},
		{
			title: '操作',
			toolbar: '#tool',
			fixed: "right",
			width: 200,
			align: "center"
		}
	]
	//插入表格数据
	table.render({
		elem: '#list',
		//height: 600,
		toolbar: '#toolbarDemo',
		defaultToolbar: [],
		url: ip + 'goods/getList', //数据接口  
		page: true,
		where: {
			userId
		},
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [colList]

	});
}



/* 授权方法 */
function setRole(url, param) {
	getData(url, param, res => {
		if (res.code == 0) {
			layer.msg("授权成功", {
				icon: 1,
				time: 1500 //2秒关闭（如果不配置，默认是3秒）
			}, function() {
				x_admin_close()
				parent.layui.table.reload('roleTable');
			});
		} else {
			layer.msg(res.msg || '授权失败', {
				icon: 2,
				time: 1500 //2秒关闭（如果不配置，默认是3秒）
			}, function() {});
		}
	})
}

/**
 * 点击搜索
 */
function toSearch(that) {
	var active = {
		reload: function() {
			var demoReload = $('#demoReload');
			var inputValue = demoReload.val();
			//执行重载
			table.reload('list', {
				url: ip + "goods/selectGoodsByName",
				where: {
					goodsTitle: inputValue
				},
				parseData: function(res) { //res 即为原始返回的数据
					if (res.code == 401) {
						top.location = '../login.html';
					}
				},
			});
		}
	};

	var type = $(that).data('type');
	active[type] ? active[type].call(that) : '';
}
