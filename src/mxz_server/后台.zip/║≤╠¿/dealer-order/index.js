var $, table, layer, form;
var admin = JSON.parse(getSession('admin'))
layui.use(['layer', 'jquery', 'form', 'table'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	form = layui.form;


	// 获取数据，渲染表格
	param = {};
	showTable()


	//监听行工具事件
	watchToolBar();

	// 监听输入单号
	watchEdit();



});


/**
 * 监听行内编辑
 */
function watchEdit() {
	table.on('edit(list)', function(obj) { //注：edit是固定事件名，test是table原始容器的属性 lay-filter="对应的值"
		let field = obj.field;
		let param = obj.data;
		// 快递单号
		if (field == "orderExpress") {
			param[field] = obj.value;
			if (param.orderStatus == 7) {
				if (!obj.value) {
					param.orderStatus = 7;
				} else {
					param.orderStatus = 2;
				}
			}
			// 更新订单
			updateOrder(param, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}
		// 备注
		else if (field == "orderMark") {
			// 更新订单
			param[field] = obj.value;
			updateOrder(param, res => {
				// 重新渲染表格
				renderCurrentPage()
			})
		}

	});
}

/**
 * 监听行工具事件
 */
function watchToolBar() {
	// 监听右边工具栏
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;
		// 扣除赔偿金
		if (obj.event === 'deduct' && resData.orderStatus == 4) {
			layer.confirm(`确定扣除全部押金(${resData.goodsDeposit/100}元)？`, {
				icon: 3,
				title: '提示',
				offset: '50%',
				fixed: false,
				scrollbar: false,
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					// 扣除押金
					getData("pay/payRest", param, res => {
						layer.close(load);
						if (res.code == 0) {
							// 更新订单状态
							resData.orderStatus = 8;
							updateOrder(resData, res => {
								layer.msg('扣除成功', {
									icon: 1,
									time: 1500
								}, function() {
									// 重新渲染表格
									renderCurrentPage();
									// refreshPage();
								});
							})

						} else {
							layer.msg(res.msg, {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
		// 解冻押金
		else if (obj.event = "unfreeze") {
			layer.confirm("确定解冻此押金？", {
				icon: 3,
				title: '提示',
				yes: function(index, layero) {
					var load;
					load = layer.load();
					param = {};
					param.orderId = resData.orderId
					getData("pay/Reunfreeze", param, res => {
						layer.close(load);
						if (res.code == 0) {
							layer.msg('解冻成功', {
								icon: 1,
								time: 1500
							}, function() {
								// 更新订单状态
								// resData.orderStatus=1
								// updateOrder(resData,res=>{})
								// 重新渲染表格
								renderCurrentPage();
							});
						} else {
							layer.msg(res.msg || "解冻失败", {
								icon: 2,
								time: 1500
							});
						}
					})
				}
			});
		}
	});

	//监听提交--搜索单号
	form.on('submit(toSubmitByNum)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.orderNo = content;
		showTable("order/selectOrderByOrderNo", param, false)
	});


	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		$("#selector option").removeAttr("selected")
		$("#selectAll").attr("selected", true);
		form.render('select');
		var content = data.field.content;
		param = {}
		param.tel = content;
		showTable("order/selectOrderByTel", param, false)
	});



	// 监听select
	form.on('select(chooseStatic)', function(data) {
		sortType = data.value;
		currentPage = 1;
		$("#searchInput").val("")
		renderCurrentPage();
	});
}

/**
 * 更新订单状态
 */
function updateOrder(resData, Callback) {
	postJsonData("order/updateOrder", resData, res => {
		Callback(res);
	})
}


/**
 * 重新渲染当前页的表格
 */
function renderCurrentPage() {
	var page = {
		curr: currentPage
	}
	// 全部订单
	if (sortType == -1 || sortType == "") showTable("order/selectOrders", {}, page)
	// 分类订单
	else {
		param = {}
		param.sortType = sortType
		showTable("order/selectOrderSortLayui", param, page)
	}
}
/**
 * 渲染表格
 */
function showTable() {
	//插入表格数据
	table.render({
		elem: '#list',
		url: ip + 'order/getList', //数据接口  
		headers: {
			token: getSession("token")
		},
		where: {
			userId: admin.userId
		},
		page: true,
		size: 'lg',
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		cols: [
			[ //表头
				{
					field: 'orderOutOrderNo',
					title: '订单编号',
					width: 150,
					align: "center",
					sort:true,
				},
				{
					field: 'orderExpress',
					title: '快递单号(点击单元格可编辑)',
					width: 240,
					style: "color:red",
					align: "center",
					sort:true,
					edit: 'text'
				},
				{
					field: 'userName',
					title: '用户名',
					align: "center",
					width: 120,
				}, {
					field: 'userTel',
					title: '用户电话',
					align: "center",
					sort:true,
					width: 150,
				}, {
					field: 'orderAddr',
					title: '订单收货地址',
					width: 250,
					align: "center",
				},
				{
					field: 'orderCreatime',
					title: '下单时间',
					sort:true,
					width: 200,
					align: "center",
				},
				
				{
					field: 'goodsTitle',
					title: '商品标题',
					width: 150,
					align: "center",
				},
				{
					field: 'orderPrice',
					title: '订单总价/元',
					width: 200,
					align: "center",
					sort:true,
					templet: "#orderPrice"
				},
				{
					field: 'attrDeposit',
					title: '商品押金',
					sort:true,
					width: 200,
					align: "center",
					templet: "#attrDeposit"
				},
				{
					field: 'attrTitle',
					title: '用户选择的属性',
					width: 200,
					align: "center"
				},		
				{
					field: 'goodsLeaseStart',
					title: '起租日期',
					width: 150,
					sort: true,
					align: "center",
					templet: "#goodsLeaseStart"
				},
				{
					field: 'goodsLeaseEnd',
					title: '第一次租赁归还日期',
					width: 180,
					sort: true,
					align: "center",
					templet: "#goodsLeaseEnd"
				},
				{
					field: 'keepRentEndTime',
					title: '续租截至日期',
					width: 150,
					sort: true,
					align: "center",
					templet: "#keepRentEndTime"
				},
				{
					field: 'leaseLimitDate',
					title: '租赁期限 (天)',
					width: 150,
					sort: true,
					align: "center"
				},
				{
					field: 'leaseTerm',
					title: '已缴费的期数',
					width: 170,
					sort: true,
					align: "center",
					templet: function(d) {
						return d.leaseTerm + "期";
					}
				},
				{
					field: 'attrPrice',
					title: '该商品属性每天的租金(元)',
					width: 250,
					sort:true,
					align: "center",
					templet: "#attrPrice"
				},
				{
					field: 'orderLeave',
					title: '留言',
					sort:true,
					align: "center",
					width: 300,
				}, {
					field: 'orderMark',
					title: '客服备注(点击单元格可编辑)',
					width: 240,
					sort:true,
					style: "color:blue",
					align: "center",
					edit: 'text'
				}, {
					field: 'orderFinalpay',
					title: '最终付款(元)',
					align: "center",
					sort:true,
					width: 270,
					templet: "#orderFinalpay"
				},
				// {
				// 	field: 'rentTermPrice',
				// 	title: '每期要缴的费用(元)',
				// 	align: "center",
				// 	width: 300,
				// 	templet:"#rentTermPrice"
				// },
				{
					title: '状态',
					align: "center",
					width: 120,
					fixed: "right",
					toolbar: '#orderStatus',
				},
				// 				{
				// 					title: '操作',
				// 					toolbar: '#tool',
				// 					fixed: "right",
				// 					width: 180,
				// 					align: "center"
				// 				},
			]
		]

	});

}
