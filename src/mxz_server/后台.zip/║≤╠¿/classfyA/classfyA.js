﻿var $, table;
var param = {};
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;	


	showTable();
	
	watchToolBar()



	//监听行工具事件
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var objData = obj.data;
		param = {}
		param = objData;
		setSession("editParam", JSON.stringify(param))
		// 跳转到修改
		if (obj.event === 'toEdit') {
			x_admin_show_all('修改一级按导航名称', './editClassfyATitle.html');
		}
		// 修改前六个分类的
		if (obj.event === 'toEdit1') {
			x_admin_show_all('修改', '../home-mid-cly/edit.html');
		}
		// 删除
		if (obj.event === 'del') {
			param = {};
			param.classfyId = objData.classfyId
			deleteTableFun(obj, "classfy/deleteClassfy", param, "确定删除此导航")
		}
		// 跳转到二级分类
		if (obj.event === 'classfyB') {
			x_admin_show_all('二级分类', '../classfyB/classfyB.html?classfyId=' + param.classfyId);
		}
	});


});


/**
 * 监听头部
 */
function watchToolBar() {
	//监听事件
	table.on('toolbar(list)', function(obj) {
		var checkStatus = table.checkStatus(obj.config.id);
		if (obj.event === 'toAdd') {
			x_admin_show('添加一级按导航名称', './addClassfyATitle.html');
		}

	});
}

/**
 * 渲染表格
 */
function showTable(pid) {
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 350,
		url: ip + 'classfy/selectClassfies', //数据接口  
		page: false,
		where: {
			pid: 0
		},
		size:'lg',
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			var data = res.data
			for (var i in data) {
				if (data[i].classfyId == 0) {
					data.splice(i, 1)
				}
			}
			return {
				data: data,
				code: res.code
			}
		},
		headers: {
			token: getSession("token")
		},
		toolbar: "#toolbar",
		defaultToolbar: [],
		cols: [
			[ //表头
				{
					field: 'classfyTitle',
					title: '一级导航名称',
					width: 250,
					align: "center"
				}, {
					title: '二级导航',
					toolbar: '#classfyB',
					align: "center"
				}, {
					title: '操作',
					toolbar: '#tool',
					fixed: "right",
					width: 300,
					align: "center"
				}
			]
		]

	});
}
