var $;
var form;
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;
	form = layui.form;

	//监听提交
	form.on('submit(submit)', function(data) {
		var param = data.field;
		param.pid = 0;
		postFormData('classfy/insertClassfy', param, res => {
			if (res.code == 0) {
				layer.msg('增加成功', {
					icon: 1,
					time :1500	
				}, function() {
					parent.location.reload(); 
					x_admin_close();
					
				});
			} else {
				layer.msg('增加失败', {
					icon: 2
				});
			}
		})
		// 		postJsonData("classfy/insertClassfy",param, res => {
		// 			console.log("提交数据返回的", res)
		// 			if (res.code == 0) {
		// 				layer.msg('修改成功', {
		// 					icon: 1,
		// 				}, function() {
		// 					x_admin_close();
		// 				});
		// 			} else {
		// 				layer.msg('修改失败', {
		// 					icon: 2
		// 				});
		// 			}
		// 		})
	});
});
