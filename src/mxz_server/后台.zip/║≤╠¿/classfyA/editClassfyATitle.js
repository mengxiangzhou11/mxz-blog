var $;
var form;
var allData =JSON.parse(getSession("editParam"))
clearSession("editParam")
layui.use(['layer', 'form', 'jquery', 'upload'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var upload = layui.upload;
	form = layui.form;
	showForm();

	//监听提交
	form.on('submit(submit)', function(data) {
		var param = data.field;
		allData.classfyTitle = param.classfyTitle
		postJsonData("classfy/updateClassfy",allData, res => {
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time :1500
				}, function() {
					parent.location.reload(); 
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
	});
});

/**
 * 渲染表单
 */
function showForm() {
	form.val("titleForm", {
		"classfyTitle": allData.classfyTitle // "name": "value"
	})

}
