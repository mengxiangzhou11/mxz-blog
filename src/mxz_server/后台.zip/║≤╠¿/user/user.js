/* 
isForm==dealer  页面来自添加经销商 
isForm==operator  页面来自添加运营员
 */
var $, table;
var isForm = 'all';
if (getUrlParam("isForm")) {
	isForm = getUrlParam("isForm");
}
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	table = layui.table;
	let colData = [{
		field: 'userName',
		title: '用户',
		width: 200,
		align: "center",
		sort: true
	}, {
		field: 'userBalance',
		title: '余额(元)',
		align: "center",
		width: 200,
		sort: true,
		templet: function(d) {
			return d.userBalance / 100 + "元";
		}
	}, {
		field: 'userTel',
		title: '电话号码',
		align: "center",
		sort: true,
	}, {
		field: 'agent',
		title: '是否代理商',
		align: "center",
		sort: true,
		templet: function(d) {
			return d.agent == 0 ? "否" : "是"
		}
	}]
	let checkData = {
		checkbox: true,
		fixed: true
	}
	if (isForm == "dealer") {
		let temp = {
			title: '经销商',
			align: "center",
			fixed: "right",
			width: 200,
			templet: "#setDister"
		};
		colData.push(temp)
		// colData.unshift(checkData)
	} else if (isForm == "operator") {
		let temp = {
			title: '运营员',
			align: "center",
			fixed: "right",
			width: 200,
			templet: "#setRole"
		};
		colData.push(temp)
		// colData.unshift(checkData)
	} else {
		// $("#moreSet").remove()
	}
	//插入表格数据
	table.render({
		elem: '#userTable',
		url: ip + 'user/selectUsersLay', //数据接口
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
		},
		size: 'lg',
		page: true, //开启分页
		// id:'list',
		cols: [
			colData
		]
	});


	// 监听select
	form.on('select(chooseStatic)', function(data) {
		// 全部
		if (data.value == -1) {
			table.reload('userTable', {
				url: ip + 'user/selectUsersLay',
			});
		} else {
			table.reload('userTable', {
				url: ip + 'user/getList',
				where: {
					roleId: data.value
				} //设定异步数据接口的额外参数
			});
		}

	});



	watchTool();
	//监听工具条 
	function watchTool() {
		table.on('tool(userTable)', function(obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
			var data = obj.data; //获得当前行数据
			var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
			var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
			let userId = data.userId;
			let param = {
				userId
			}
			//设置运营员
			if (layEvent === 'setRole') {
				layer.confirm('确定授权当前用户为运营员?', {
					icon: 3,
					title: '提示'
				}, function(index) {
					//do something
					setRole("userRole/grantOperator", param);
					layer.close(index);
				});
			}
			//设置经销商
			else if (layEvent === 'setDister') {
				layer.confirm('确定授权当前用户为经销商?', {
					icon: 3,
					title: '提示'
				}, function(index) {
					setRole("userRole/grantDister", param)
					layer.close(index);
				});
			}
		});
	}

	/* 搜索用户 */
	(function searchUser() {
		//监听提交
		form.on('submit(search)', function(data) {
			let value = data.field.name;
		});
	})();

	/* 授权方法 */
	function setRole(url, param) {
		getData(url, param, res => {
			if (res.code == 0) {
				layer.msg("授权成功", {
					icon: 1,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function() {
					x_admin_close()
					parent.layui.table.reload('roleTable');
				});
			} else {
				layer.msg(res.msg || '授权失败', {
					icon: 2,
					time: 1500 //2秒关闭（如果不配置，默认是3秒）
				}, function() {});
			}
		})
	}

	// 多个用户授权
	window.toSet = function() {
		var checkStatus = table.checkStatus('userTable');
		var userData = checkStatus.data;
		let userIds = [];
		for (var i in userData) {
			userIds.push(userData[i].userId)
		}
		if (userIds.length < 1) {
			layer.msg('请先选择用户', {
				icon: 2,
				time: 1500
			});
			return;
		}
		let param = {
			userId: userIds.join(',')
		}
		if (isForm == "dealer") {
			layer.confirm('确定授权选择的用户为经销商?', {
				icon: 3,
				title: '提示'
			}, function(index) {
				setRole("userRole/grantDister", param)
				layer.close(index);
			});
		} else if (isForm == "operator") {
			layer.confirm('确定授权选择的用户为运营员?', {
				icon: 3,
				title: '提示'
			}, function(index) {
				setRole("userRole/grantOperator", param);
				layer.close(index);
			});
		}
	}

	//监听提交--搜索姓名
	form.on('submit(toSubmitByName)', function(data) {
		var content = data.field.content;
		table.reload('userTable', {
			url: ip + 'user/selectUserByName',
			where: {
				userName: content
			}
		});
		layer.msg("数据已更新");
	});


	//监听提交--搜索手机号
	form.on('submit(toSubmitByPhone)', function(data) {
		var content = data.field.content;
		table.reload('userTable', {
			url: ip + 'user/selectUserByTel',
			where: {
				tel: content
			}
		});
		layer.msg("数据已更新");
	});

});

/**
 * 渲染表格
 */
function showTable(url, param, page) {

	//插入表格数据
	table.render({
		elem: '#userTable',
		url: ip + url, //数据接口  
		headers: {
			token: getSession("token")
		},
		page: page,
		where: param,
		// toolbar: '#Exportbar',
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
			if (res.data instanceof Array == false) {
				var data = [];
				res.data ? data[0] = res.data : ""
				return {
					"data": data,
					"code": res.code
				}
			}
		},
		done: function(res, curr, count) {
			currentPage = curr
		},
		cols: [{
			field: 'userName',
			title: '用户',
			width: 200,
			align: "center",
			sort: true
		}, {
			field: 'userBalance',
			title: '余额(元)',
			align: "center",
			width: 200,
			sort: true,
			templet: function(d) {
				return d.userBalance / 100 + "元";
			}
		}, {
			field: 'userTel',
			title: '电话号码',
			align: "center",
			sort: true,
		}, {
			field: 'agent',
			title: '是否代理商',
			align: "center",
			sort: true,
			templet: function(d) {
				return d.agent == 0 ? "否" : "是"
			}
		}]
	});

}
