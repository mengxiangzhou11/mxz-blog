﻿var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;
	//插入表格数据
	table.render({
		elem: '#userTable',
		url: ip + 'user/searchRentalStatus', //数据接口
		headers: {
			token: getSession("token")
		},
		parseData: function(res) {
			if (res.code == 401) {
				top.location='../login.html';
			}
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
		},
		size: 'lg',
		page: true, //开启分页
		cols: [
			[ //表头
				{
					field: 'userName',
					title: '用户',
					width: 200,
					align: "center",
				}, {
					field: 'uuid',
					title: 'uuid',
					align: "center",
					width: 200
				}, {
					field: 'userLogo',
					title: '头像',
					align: "center",
					templet: function(d) {
						return `<img style="height: 100%;max-width: 100%;" src=' ${d.userLogo}'/>`
					}
					
				}, {
					field: 'rentalStatus',
					title: '状态',
					align: "center",
					 templet: function (d) {
					    return d.rentalStatus == 0 ? "正常" : "逾期";
					}
				}, {
					field: 'userTel',
					title: '联系电话',
					align: "center",
					width: 200
				}
			]
		]
	});


});
