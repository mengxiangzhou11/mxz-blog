var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;

	init();

	//初始化表单数据
	function init() {
		let withdrawId = getUrlParam("withdrawId");
		if (withdrawId != null) {
			getData('withdraw/searchWithdrawById', {
				"withdrawId": withdrawId
			}, res => {
				if (res.code == 0) {
					userLogo = res.data.userLogo; //用户头像
					credentials = res.data.credentials; //相关证明
					form.val('withdrawfilter', {
						'withdrawId': res.data.withdrawId,
						'userId': res.data.userId,
						'userName': res.data.userName,
						'userLogo': res.data.userLogo,
						'alipayNickname': res.data.alipayNickname,
						'alipayAccount': res.data.alipayAccount,
						'remark': res.data.remark,
						'withdrawAmount': res.data.withdrawAmount / 100,
						'withdrawTime': formatDate(parseInt(res.data.withdrawTime)),
						'credentials': res.data.credentials,
					})
					$('#logo').attr('src', userLogo);
					$('#pic').attr('src', ip + credentials);
				}
			})
		}
	}


	//监听审核成功的方法
	form.on('submit(pass)', function(data) {
		var param = data.field;
		// var withdrawId=$('input[name="withdrawId"]').val();
		getData('withdraw/updateWithdrawStatus', {
			"withdrawId": param.withdrawId,
			"status": 1
		}, res => {
			console.log(res)
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time: 1000
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
		return false;
	});

	//审核失败的方法
	form.on('submit(fail)',function(data) {
		var param = data.field;
		getData('withdraw/updateWithdrawStatus', {
			"withdrawId": param.withdrawId,
			"status": 2
		}, res => {
			console.log(res)
			if (res.code == 0) {
				layer.msg('修改成功', {
					icon: 1,
					time: 1000
				}, function() {
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg('修改失败', {
					icon: 2
				});
			}
		})
		return false;
	});

	//监听返回的方法
	form.on('submit(reback)', function(data) {
		parent.location.reload();
		x_admin_close();
	})

	$("#pic").click(function(){
		var picUrl=$("#pic").attr("src");
			layer.photos({
		        photos:{"data":[{"src":picUrl}]}
		    }) 
	})
});
