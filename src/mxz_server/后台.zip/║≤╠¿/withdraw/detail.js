var $;
layui.use(['layer', 'form', 'jquery', 'table'], function() {
	var layer = layui.layer;
	$ = layui.jquery;
	var form = layui.form;
	var table = layui.table;


	//初始化表单数据
	init();



	function init() {
		let withdrawId = getUrlParam("withdrawId");
		if (withdrawId != null) {
			getData('withdraw/searchWithdrawById', {
				"withdrawId": withdrawId
			}, res => {
				if (res.code == 0) {
					console.log(res);
					userLogo = res.data.userLogo; //用户头像
					credentials = res.data.credentials; //相关证明
					form.val('testfilter', {
						'withdrawId': res.data.withdrawId,
						'userId': res.data.userId,
						'userName': res.data.userName,
						'userLogo': res.data.userLogo,
						'alipayNickname': res.data.alipayNickname,
						'alipayAccount': res.data.alipayAccount,
						'remark': res.data.remark,
						'withdrawAmount': res.data.withdrawAmount / 100,
						'withdrawTime': formatDate(parseInt(res.data.withdrawTime)),
						'credentials': res.data.credentials,
					})
					$('#logo').attr('src', userLogo);
					$('#pic').attr('src', ip + credentials);
				}
			})
		}
	}
	form.on('submit(reback)', function(data) {
		parent.location.reload();
		x_admin_close();
	})
	
	$("#pic").click(function(){
		var picUrl=$("#pic").attr("src");
			layer.photos({
		        photos:{"data":[{"src":picUrl}]}
		    }) 
	})
});

