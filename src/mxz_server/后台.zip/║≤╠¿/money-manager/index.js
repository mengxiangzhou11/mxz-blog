var $;
layui.use(['layer', 'form', 'jquery', 'table', 'laydate'], function() {
	$ = layui.jquery;
	var layer = layui.layer;
	var form = layui.form;
	var table = layui.table;
	var laydate = layui.laydate;


	//插入表格数据
	var tableIns = table.render({
		elem: '#withdraw',
		url: ip + 'payRec/getList', //数据接口
		headers: {
			token: getSession("token")
		},
		totalRow: true,
		where: {},
		parseData: function(res) {
			if (res.code == 401) {
				top.location = '../login.html';
			}
			let resData = res.data;
			for (var i in resData) {
				resData[i].total = resData[i].order.attrDeposit
				// resData[i].total = resData[i].finalPay + resData[i].restPay
			}
			return {
				"code": res.code, //解析接口状态
				"count": res.count, //解析数据长度
				"data": resData //解析数据列表
			};
		},
		done: function(res, curr, count) {
			//如果是异步请求数据方式，res即为你接口返回的信息。
			//如果是直接赋值的方式，res即为：{data: [], count: 99} data为当前页数据、count为数据总长度
			var total1=$('.layui-table-total').find('tr').find('td').eq(1).find('div').eq(0).html();
			$('.layui-table-total').find('tr').find('td').eq(1).find('div').eq(0).html(total1/100+'元')
			var total2=$('.layui-table-total').find('tr').find('td').eq(2).find('div').eq(0).html();
			$('.layui-table-total').find('tr').find('td').eq(2).find('div').eq(0).html(total2/100+'元')
			var total3=$('.layui-table-total').find('tr').find('td').eq(3).find('div').eq(0).html();	
			$('.layui-table-total').find('tr').find('td').eq(3).find('div').eq(0).html(total3/100+'元')
			var total4=$('.layui-table-total').find('tr').find('td').eq(4).find('div').eq(0).html();
			$('.layui-table-total').find('tr').find('td').eq(4).find('div').eq(0).html(total4/100+'元')
		},
		id: 'all',
		size: 'lg',
		page: true, //开启分页	
		cols: [
			[ //表头
				{
					field: 'orderOutorderno',
					title: '订单号',
					width: 200,
					sort: true,
					totalRowText: "合计",
					align: "center",
				}, {
					field: 'amount',
					title: '本次扣款金额（元）',
					align: "center",
					totalRow: true,
					width: 180,
					sort: true,
					templet: function(d) {
						return d.amount / 100;
					}
				},
				{
					field: 'finalPay',
					title: '累计扣款的金额(元)',
					align: "center",
					totalRow: true,
					width: 180,
					sort: true,
					templet: function(d) {
						return d.finalPay / 100;
					}
				},

				{
					field: 'restPay',
					title: '剩余待扣款金额(元)',
					align: "center",
					totalRow: true,
					width: 180,
					sort: true,
					templet: function(d) {
						return d.restPay / 100;
					}
				},
				{
					field: 'total',
					title: '总押金(元)',
					align: "center",
					totalRow: true,
					width: 120,
					sort: true,
					templet: function(d) {
						return d.total / 100;
					}
				}, {
					field: 'note',
					title: '备注',
					align: "center",
				}, {
					field: 'createtime',
					title: '时间',
					align: "center",
					width: 250,
					sort: true,
					templet: function(d) {
						return formatDate(parseInt(d.createtime))
					}
				}, {
					title: '操作',
					align: "center",
					fixed: "right",
					width: 120,
					templet: function(d) {
						return `<span class="layui-btn" lay-event="toDetail">详情</span>`
					}
				}
			]
		]
	});


	//日期
	laydate.render({
		elem: '#test1',
		type: 'datetime',
		range: true, //或 range: '~' 来自定义分割字符
		done: function(value, date, endDate) {
			let temp = value.split(" - ");
			let start = temp[0];
			let end = temp[1];
			start = new Date(start)
			end = new Date(end)
			start = start.getTime()
			end = end.getTime();
			tableIns.reload({
				where: {
					start,
					end
				}
			});
		},
	});


	table.on('tool(withdraw)', function(obj) { //注：tool 是工具条事件名，test 是 table 原始容器的属性 lay-filter="对应的值"
		var data = obj.data; //获得当前行数据
		var layEvent = obj.event; //获得 lay-event 对应的值（也可以是表头的 event 参数对应的值）
		var tr = obj.tr; //获得当前行 tr 的 DOM 对象（如果有的话）
		//查看详情
		if (layEvent === 'toDetail') {
			setSession("curOrder", JSON.stringify(data.order))
			x_admin_show("详情", "../mon-man-detail/index.html")
		}
	});
});
