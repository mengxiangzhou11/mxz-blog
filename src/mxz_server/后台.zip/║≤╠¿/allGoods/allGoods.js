/**
 * 当前页面有三张方式进入
 * 1.导航栏的商品->所有商品，可对商品进行增删该
 * 2.首页管理->商品分类->商品，可把导航栏的商品->所有商品添加/移除至当前分类
 * 3.分类商品管理->商品分类->商品，可把导航栏的商品->所有商品添加/移除至当前分类
 * isFormIndex==index  导航栏的商品->所有商品
 * isFormIndex==dealer 来自经销商页面，可授权商品到经销商
 */

var $, table, layer, laytpl;
var param = {};
var classfyId = getUrlParam("classfyId");
var userId = getUrlParam("userId");
var isFormIndex = false; //判断是否从首页的商品跳转的页面
if (getUrlParam("isFormIndex")) {
	isFormIndex = getUrlParam("isFormIndex")
}
layui.use(['layer', 'jquery', 'table', 'laytpl'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	table = layui.table;
	laytpl = layui.laytpl;

	// 获取数据
	showTable()


	//监听行工具事件
	watchToolBar();

	// 点击搜索
	toSearch();


	// 监听选中行
	watchSelect()




});

/**
 * 监听行工具事件
 */
function watchToolBar() {
	table.on('tool(list)', function(obj) {
		var index = $("tr").index(obj.tr) - 1;
		var resData = obj.data;

		// 修改商品
		if (obj.event === 'toEdit') {
			x_admin_show_all('修改商品', '../goods/editGood.html?goodsId=' + resData.goodsId);
		}
		// 删除商品
		if (obj.event === 'del') {
			let param = {
				goodsId: resData.goodsId
			}
			deleteTableFun(obj, "goods/deleteGoods", param, "确定删除此商品")
		}
		if (obj.event === 'toCopy') {
			let goodId = resData.goodsId;
			getData('goods/copyGoods', {
				goodId
			}, res => {
				layer.alert("复制成功!", {
					icon: 1
				})
			})
		}
		// 管理属性
		if (obj.event === 'toAttr') {
			setSession("good", JSON.stringify(resData))
			x_admin_show_all_ref('属性', '../attr/attr.html?goodsId=' + resData.goodsId);
		}
		// 授权经销商
		if (obj.event === 'toRole') {
			layer.confirm('确定授权此经销商到商品?', {
				icon: 3,
				title: '提示'
			}, function(index) {
				let param1 = {
					userId,
					goodIds: resData.goodsId
				}
				postFormData("userGood/inserUserGood", param1, res => {
					if (res.code == 0) {
						layer.msg("授权成功", {
							icon: 1,
							time: 1500 //2秒关闭（如果不配置，默认是3秒）
						}, function() {
							x_admin_close()
							parent.layui.table.reload('list');
						});
					} else {
						layer.msg(res.msg || '授权失败', {
							icon: 2,
							time: 1500 //2秒关闭（如果不配置，默认是3秒）
						}, function() {});
					}
				})
				layer.close(index);
			});

		}

	});
}

/**
 * 监听选中行
 * 监听表格头部
 */
function watchSelect() {
	table.on('toolbar(list)', function(obj) {
		var checkStatus = table.checkStatus(obj.config.id);
		var goods = checkStatus.data
		switch (obj.event) {
			case 'insertGoodsClassfy':
				// 添加商品至分类
				addSelect(goods, 0, res => {})
				break;
			case 'reload':
				toSearch(this)
				break;
				// 添加商品
			case 'toAdd':
				toAdd()
				break;
		};
	});
}

/**
 * 跳转到添加商品
 */
function toAdd() {
	x_admin_show_all_ref('添加商品', '../goods/addGood.html');
}


/**
 * 添加所选的到此分类
 */
function addSelect(array, index, Callback) {
	if (array.length == 0) {
		layer.msg('您尚未选择要添加的商品', {
			icon: 0
		});
		return;
	}
	var load = layer.load(0, {
		offset: '50%',
		fixed: false,
		scrollbar: false
	});
	if (array.length == index) {
		layer.close(load);
		layer.msg('增加成功', {
			icon: 1,
			time: 1500
		});
		return;
		callBack();
	} else {
		var param = {
			goodsId: array[index].goodsId,
			classfyId: classfyId
		}
		getData('goodsClassfy/insertGoodsClassfy', param, res => {
			if (res.code == 0) {
				index++;
				addSelect(array, index, Callback)
			} else {
				layer.close(load);
				layer.msg('增加失败', {
					icon: 2
				});
			}
		})
	}

}
/**
 * 渲染表格
 */
function showTable() {
	var colList = [ //表头
		{
			checkbox: true,
			fixed: true
		},
		{
			field: 'goodsId',
			title: 'Id',
			width: 100,
			fixed: 'left',
			align: "center",
			sort: true
		},
		{
			field: 'goodsTitle',
			title: '商品名称',
			width: 250,
			align: "center",
			sort: true
		}, {
			field: 'goodsDesc',
			title: '商品描述',
			align: "center",
			width: 300,
			sort: true
		}, {
			title: '商品属性',
			align: "left",
			toolbar: '#attr',
			width: 300,
			sort: true
		},
		{
			field: 'goodsMinPrice',
			title: '封面价格/元（只用作显示）',
			align: "center",
			width: 250,
			sort: true,
			templet: "#goodsMinPrice"
		}, {
			field: 'transport',
			title: '快递方式',
			width: 180,
			align: "center",
			templet: function(d) {
				return d.transport == 0 ? "包邮" : "到付"
			}
		}, {
			field: 'goodsCover',
			title: '商品封面图',
			width: 120,
			align: "center",
			templet: '#img1'
		}, {
			field: 'goodsBanner',
			title: '商品轮播图',
			width: 250,
			align: "center",
			templet: '#img2'
		}, {
			field: 'goodsIntroduce',
			title: '商品介绍图',
			width: 250,
			align: "center",
			// templet: '#img3'
		}, {
			field: 'goodsParameter',
			title: '租赁流程图',
			width: 250,
			align: "center",
			// templet: '#img4'
		}, {
			field: 'goodsTip',
			title: '租赁必读图',
			width: 250,
			align: "center",
			// templet: '#img5'
		}, {
			field: 'goodsPackPrice',
			title: '本店活动',
			width: 180,
			align: "center",
			sort: true
		}, 
		// {
		// 	field: 'goodsSaleNum',
		// 	title: '销售数量',
		// 	width: 120,
		// 	align: "center",
		// 	sort: true
		// }, {
		// 	field: 'goodsSkin',
		// 	title: '浏览量',
		// 	width: 120,
		// 	align: "center",
		// 	sort: true
		// }, {
		// 	field: 'goodsStock',
		// 	title: '库存',
		// 	width: 80,
		// 	align: "center",
		// 	sort: true
		// },
		{
			title: '操作',
			toolbar: '#tool',
			fixed: "right",
			width: 200,
			align: "center"
		}
	]
	if (isFormIndex == "index") {
		colList.shift()
	} else {
		colList.pop()
	}
	if (isFormIndex == "dealer") {
		let temp = {
			title: '经销商',
			fixed: "right",
			width: 150,
			align: "center",
			templet: "#toRole"
		};
		colList.shift()
		colList.push(temp)
	}
	//插入表格数据
	table.render({
		elem: '#list',
		// height: 600,
		toolbar: '#toolbarDemo',
		defaultToolbar: [],
		url: ip + 'goods/selectAllGoods', //数据接口  
		page: false,
		headers: {
			token: getSession("token")
		},
		parseData: function(res) { //res 即为原始返回的数据
			if (res.code == 401) {
				top.location = '../login.html';
			}
		},
		cols: [colList]

	});
}





/**
 * 点击搜索
 */
function toSearch(that) {
	var active = {
		reload: function() {
			var demoReload = $('#demoReload');
			var inputValue = demoReload.val();
			//执行重载
			table.reload('list', {
				url: ip + "goods/selectGoodsByName",
				where: {
					goodsTitle: inputValue
				},
				parseData: function(res) { //res 即为原始返回的数据
					if (res.code == 401) {
						top.location = '../login.html';
					}
				},
			});
		}
	};

	var type = $(that).data('type');
	active[type] ? active[type].call(that) : '';
}
