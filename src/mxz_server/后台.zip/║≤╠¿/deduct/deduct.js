var $, layer, form;
var formData;
var orderId=getUrlParam("orderId");
layui.use(['layer', 'form', 'jquery'], function() {
	layer = layui.layer;
	$ = layui.jquery;
	form = layui.form;



	//监听提交
	var load2;
	form.on('submit(submit)', function(data) {
		load2 = layer.load();
		var param = data.field;
		param.orderId=orderId;
		param.amount = parseInt( param.amount * 100);
		getData("pay/damagePay", param, res => {
			layer.close(load2);
			if (res.code == 0) {
				layer.msg('扣除成功', {
					icon: 1,
					time: 1500
				},function(){
					parent.location.reload();
					x_admin_close();
				});
			} else {
				layer.msg(res.msg, {
					icon: 2
				});
			}
		})
	});
});

/**
 * 渲染表单
 */
function showForm(data) {
	form.val("columnForm", {
		"originPrice": formData.extraDesc/100,
		"presentPrice": formData.extraSrc/100,
	})
}
